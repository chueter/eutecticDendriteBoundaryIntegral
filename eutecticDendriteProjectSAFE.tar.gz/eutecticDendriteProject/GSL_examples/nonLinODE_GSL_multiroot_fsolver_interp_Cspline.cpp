#include <iostream>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_multiroots.h>
#include <gsl/gsl_interp.h>
#include <gsl/gsl_spline.h>

#define numberGridPoints  100

using namespace std;

struct parameters{
double lambda;
};

size_t iterations(0);
const gsl_interp_type* splineT = gsl_interp_cspline;
//gsl_spline* spline = gsl_spline_alloc(splineT,numberGridPoints);
double xGrid[numberGridPoints];
//gsl_interp_accel* accel1 = gsl_interp_accel_alloc();

void update_spline(const gsl_vector* x);
void setNumericalParameters(double& Length,double& initialDiscretization, double& error_tol, string& gridSwitch);
void initializeGrid(double& Length, double& discretization, string& gridSwitch);
void printState (gsl_multiroot_fsolver* solver);
void initializeSolutionVector(double* initialGuess, gsl_vector* x);
int equationSystem_nonlinODE(const gsl_vector* x, void* params, gsl_vector* equationVector);

int main()
{
	double discretization(0.),error_tol(1.),Length(0.);
	string gridSwitch;
	int status(0);
	double initialGuess[numberGridPoints];
	struct parameters nonlinODE_Parameters = {1.0};
	gsl_vector* x = gsl_vector_calloc(numberGridPoints);

	setNumericalParameters(Length,discretization,error_tol,gridSwitch);
	initializeGrid(Length,discretization,gridSwitch);
	initializeSolutionVector(initialGuess,x);
 	//gsl_spline_init(spline,xGrid,initialGuess,numberGridPoints);

	const gsl_multiroot_fsolver_type* fsolverT = gsl_multiroot_fsolver_hybrids;
	gsl_multiroot_fsolver* solver1= gsl_multiroot_fsolver_alloc(fsolverT,numberGridPoints) ;
	gsl_multiroot_function model_nonlinODE = {&equationSystem_nonlinODE, numberGridPoints, &nonlinODE_Parameters};
	gsl_multiroot_fsolver_set(solver1,&model_nonlinODE,x);
 	printState(solver1);
 	
	do
	{
		iterations++;
		status = gsl_multiroot_fsolver_iterate(solver1);
		printState(solver1);

		if (status) {break;}

		status = gsl_multiroot_test_residual(solver1->f, error_tol);
	}
	while (status == GSL_CONTINUE && iterations < 1000);
	
	cout << "status= " << gsl_strerror(status) << endl;

	for (int i=0;i<numberGridPoints;i++)
	{
		cout << i << " x= " << xGrid[i] << " root[i]= " << gsl_vector_get(solver1->x, i) << " solution= " << 2.*xGrid[i]+4. << endl;
	}

	gsl_multiroot_fsolver_free(solver1);
	gsl_vector_free(x);
	//gsl_interp_accel_free(accel1);

return 0;
}	

///////////////////////////////////////////////////////////////////////
void initializeGrid(double& Length, double& discretization, string& gridSwitch)
{
	if(gridSwitch=="uniform")
	{
	for (int xGridIndex = 0; xGridIndex < numberGridPoints; ++xGridIndex)
		{
			xGrid[xGridIndex] = xGridIndex*discretization; 
		} 
	}	
	
	if (gridSwitch=="quadratic")
	{
		for (int xGridIndex = 0; xGridIndex < numberGridPoints; ++xGridIndex)
		{
			double Length(numberGridPoints*discretization);
			xGrid[xGridIndex] = Length*pow( (xGridIndex/(numberGridPoints*1.) ),2.) ;
		}	
	}
	
	
	std::cout << "gridType: " << gridSwitch << std::endl;
	for (int xGridIndex = 0; xGridIndex < numberGridPoints; ++xGridIndex)
	{
		std::cout << xGrid[xGridIndex] << " is x at gridIndex= " << xGridIndex << std::endl;
	}
}
////////////////////////////////////////////////////////////////////////
void setNumericalParameters(double& Length, double& initialDiscretization, double& error_tol, string& gridSwitch)
{
	initialDiscretization = 0.1;
	gridSwitch = "quadratic";
	//gridSwitch = "uniform";
	error_tol = 1e-7;
	Length = numberGridPoints*initialDiscretization;
}
/////////////////////////////////////////////////////////////////////////
int equationSystem_nonlinODE(const gsl_vector* x, void* params,gsl_vector* equationVector)
{
	double a = ((struct parameters*) params)-> lambda; // <=> a = (params*).c1, where params* points to instance of type struct parameters* : pointer of type params* points to instance of type parameters that has element c1 and c2
	double equation[numberGridPoints];	
	double dydx(0.),y(0.),y_0;
	double x_i(0.);
	double yData[numberGridPoints];
	gsl_spline* current_spline = gsl_spline_alloc(splineT,numberGridPoints);
	gsl_interp_accel* current_accel = gsl_interp_accel_alloc();
	for(int i =0; i< numberGridPoints;i++)
	{
		yData[i] = gsl_vector_get(x,i);
	}
	gsl_spline_init(current_spline,xGrid,yData,numberGridPoints);
	

	//update_spline(x,);

	y_0 = gsl_spline_eval(current_spline,0.,current_accel);
	equation[0] = y_0-4.;
	for (int i = 1; i< numberGridPoints;i++)
	{
		x_i = xGrid[i];	
		y = gsl_spline_eval(current_spline,x_i,current_accel);
		dydx = gsl_spline_eval_deriv(current_spline,x_i,current_accel);
		//equation[i] = pow((dydx-exp(-a*xGrid[i])),2.0)-pow(y,2.0);
		equation[i] = dydx*(x_i+2.)*(2.*x_i+4.)-y*y;
	
		//cout << " x_i= " << x_i << " y= " << y << " dydx= " << dydx << " eq[i]= " << equation[i] << endl;

	}
	//if (iterations > 1) {exit(1);}

	for(int i = 0; i< numberGridPoints; i++)
	{
		gsl_vector_set(equationVector,i,equation[i]);
	}

	gsl_interp_accel_free(current_accel);
	gsl_spline_free(current_spline);

	return GSL_SUCCESS;
}
/////////////////////////////////////////////////////////////////////////
void initializeSolutionVector(double* initialGuess,gsl_vector* x)
{
	for (int i = 0; i<numberGridPoints; i++)
	{
		initialGuess[i] = 2.;
		gsl_vector_set(x,i,initialGuess[i]);
	}	
}
/////////////////////////////////////////////////////////////////////
void printState (gsl_multiroot_fsolver* solver)
{
	cout << "iterations= " << iterations << " x_0= " << gsl_vector_get(solver->x, 0) << " sum_i |f_i(x)|= " << ( fabs(gsl_vector_get(solver->f, 0))+fabs(gsl_vector_get(solver->f, 1)) ) << endl;    

}
/////////////////////////////////////////////////////////////////
// void update_spline(const gsl_vector* x)
// {
// 	double rootEstimate[numberGridPoints];
// 	
// 	for (int i=0;i<numberGridPoints;i++)
// 	{
// 		rootEstimate[i] = gsl_vector_get(x,i);
// 	}
// 	gsl_spline_init(spline,xGrid,rootEstimate,numberGridPoints);
// }
//////////////////////////////////////////////////////////////////////








