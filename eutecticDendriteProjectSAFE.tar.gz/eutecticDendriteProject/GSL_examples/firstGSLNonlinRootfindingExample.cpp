#include <iostream>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_multiroots.h>

using namespace std;
// dieses programm ist das erste beispielprogramm fuer die GSL solver fuer nichtlineare gleichungssysteme.
// beschreibung:
/*
mit gsl muessen folgende objekte angelegt werden: 
der typ T* des solvers der benutzt werden soll, resp. der solver die benutzt werden sollen, muss angelegt werden: 
const gsl_multiroot_fsolver_type* solverType1 = gsl_multiroot_fsolver_hybrid;

es muessen n funktionen in den n variablen fuer den solver angelegt werden, in einer instanz des typs 
gsl_multiroot_function(ohne Jacobian), dabei hat gsl_multiroot_function die felder 
int (*f) (const gsl_vector* x, void* params, gsl_vector* f),
size_t n,
void* params
der erste gsl_vector* x ist der pointer des loesungsvektors/initialguess, params ist ein generischer pointer weil noch nicht klar ist wieviele parameter das gleichungssystem hat, gsl_vector* f ist der pointer des vektors fuer das gleichungsystem

eine instanz eines solvers ohne jacobian des typs T fuer n dimensionen: 
gsl_multiroot_fsolver * gsl_multiroot_fsolver_alloc(const gsl_multiroot_fsolver_type *T, size_t n)
legt solvertyp und dimension fest,
gsl_multiroot_fsolver_set(gsl_multiroot_solver* s, gsl_multiroot_function* f, const gsl_vector* x)
ordnet einem solver s eine funktionf und initialguess x zu - z wird nicht geaendert durch den solver.

eine instanz die den status des solvers in zwischen den iterationen angibt, um die konvergenz des codes beurteilen und abbruchbedingungen einfuehren zu koennen:
int status(0);
status = gsl_multiroot_test_residual ((*s).f, 1e-7)  um festzustellen ob f insgesamt um mehr als 1e-7 groesser 0 ist. 
die abbruchbedingungen 
gsl_multiroot_test_residual (const gsl_vector* f, double epsabs) und
gsl_multiroot_test_delta(const gsl_vector* dx, const gsl_vector* x, double epsabs, double epsrel)
testen die absolute summierte abweichung des gleichungssystems und den fortschritt der konvergenz. 
*/

struct parameters
{
double c1;
double c2;
};


void printState (size_t& iterations, gsl_multiroot_fsolver* solver);
int equationSystem_rosenbrock(const gsl_vector* x, void* params, gsl_vector* equationVector);




int main()
{
	size_t iterations(0), numberGridPoints(2);
	int status(0);
	double initialGuess[2];

	const gsl_multiroot_fsolver_type* T;
	gsl_multiroot_fsolver* solver1;
	gsl_vector* x = gsl_vector_calloc(numberGridPoints);
	struct parameters rosenbrockParameters = {1.0, 10.0};
	gsl_multiroot_function model_rosenbrock = {&equationSystem_rosenbrock, numberGridPoints, &rosenbrockParameters};

	initialGuess[0] = -10.0;  
	initialGuess[1] = -5.0; 
	gsl_vector_set(x,0,initialGuess[0]);
	gsl_vector_set(x,1,initialGuess[1]);
	
	T = gsl_multiroot_fsolver_hybrids;
	solver1 = gsl_multiroot_fsolver_alloc(T,numberGridPoints);
	gsl_multiroot_fsolver_set(solver1,&model_rosenbrock,x);

	printState(iterations,solver1);
	
	do
	{
		iterations++;
		status = gsl_multiroot_fsolver_iterate(solver1);
		printState(iterations,solver1);

		if (status) {break;}

		status = gsl_multiroot_test_residual(solver1->f, 1e-7);
	}
	while (status == GSL_CONTINUE && iterations < 1000);
	
	cout << "status= " << gsl_strerror(status) << endl;

	gsl_multiroot_fsolver_free(solver1);
	gsl_vector_free(x);


return 0;
}

void printState (size_t& iterations, gsl_multiroot_fsolver* solver)
{
	cout << "iterations= " << iterations << " x= (" << gsl_vector_get(solver->x, 0) << "," << gsl_vector_get(solver->x,1) << ") sum_i |f_i(x)|= " << ( fabs(gsl_vector_get(solver->f, 0))+fabs(gsl_vector_get(solver->f, 1)) ) << endl;    

}

int equationSystem_rosenbrock(const gsl_vector* x, void* params,gsl_vector* equationVector)
{
	double a = ((struct parameters*) params)-> c1; // <=> a = (params*).c1, where params* points to instance of type struct parameters* : pointer of type params* points to instance of type parameters that has element c1 and c2
	double b = ((struct parameters*) params)-> c2;

	const double x0(gsl_vector_get (x,0));
	const double x1(gsl_vector_get (x,1));
	
	const double equation_0(a*(1-x0));
	const double equation_1(b*(x1-x0*x0));

	gsl_vector_set(equationVector,0,equation_0);
	gsl_vector_set(equationVector,1,equation_1);

	return GSL_SUCCESS;
}

