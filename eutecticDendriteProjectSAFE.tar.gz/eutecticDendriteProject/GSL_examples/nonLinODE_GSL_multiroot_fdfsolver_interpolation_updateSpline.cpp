#include <iostream>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_multiroots.h>
#include <gsl/gsl_interp.h>
#include <gsl/gsl_spline.h>

#define numberGridPoints  100

using namespace std;

struct parameters{
double lambda;
};

struct integralParameters{
double xObserv;
gsl_spline* splineG1loc;
gsl_interp_accel* accelG1loc;
gsl_spline* splineG2loc;
gsl_interp_accel* accelG2loc;
};



size_t iterations(0);
const gsl_interp_type* splineT = gsl_interp_cspline;
double xGrid[numberGridPoints];

void setNumericalParameters(double& Length,double& initialDiscretization, double& error_tol, string& gridSwitch);
void initializeGrid(double& Length, double& discretization, string& gridSwitch);
void printState (gsl_multiroot_fdfsolver* solver);
void updateSpline(const gsl_vector* x, gsl_spline* localSplineG1, gsl_interp_accel* localAccelG1);
void initializeSolutionVector(double* initialGuess, gsl_vector* x);
int set_equationSystem_nonlinODE(const gsl_vector* x, void* params, gsl_vector* equationVector);
int set_equationSystem_nonlinODE_fdf(const gsl_vector* x, void* params, gsl_vector* equationVector, gsl_matrix* jacobian);
int set_jacobian_equationSystem_nonlinODE(const gsl_vector* x, void* params, gsl_matrix* jacobian);


int main()
{
	double discretization(0.),error_tol(1.),Length(0.);
	string gridSwitch;
	int status(0);
	double initialGuess[numberGridPoints];
	
	struct parameters nonlinODE_Parameters = {1.0};
	gsl_vector* x = gsl_vector_calloc(numberGridPoints);
	

	setNumericalParameters(Length,discretization,error_tol,gridSwitch);
	initializeGrid(Length,discretization,gridSwitch);
	initializeSolutionVector(initialGuess,x);

 	
//////////////////////////////////regular nonlin ode ///////////////////////////////////////////////////////////////
	const gsl_multiroot_fdfsolver_type* fdfsolverT = gsl_multiroot_fdfsolver_hybridsj;/*gnewton*/
	gsl_multiroot_fdfsolver* solver1= gsl_multiroot_fdfsolver_alloc(fdfsolverT,numberGridPoints) ;
	
	gsl_multiroot_function_fdf model_nonlinODE = 						{&set_equationSystem_nonlinODE,&set_jacobian_equationSystem_nonlinODE,&set_equationSystem_nonlinODE_fdf, numberGridPoints, &nonlinODE_Parameters};
	
	gsl_multiroot_fdfsolver_set(solver1,&model_nonlinODE,x);

 	printState(solver1);


//////////////////////////////////////////////////////////////////////////////////////////////////
	do
	{
		iterations++;
		status = gsl_multiroot_fdfsolver_iterate(solver1);
		printState(solver1);

		if (status) {break;}

		status = gsl_multiroot_test_residual(solver1->f, error_tol);
	}
	while (status == GSL_CONTINUE && iterations < 1000);
	
	cout << "status= " << gsl_strerror(status) << endl;

	for (int i=0;i<numberGridPoints;i++)
	{
		cout << i << " x= " << xGrid[i] << " root[i]= " << gsl_vector_get(solver1->x, i) << " solution= " << /*2.*xGrid[i]+4.*/ /*1.-xGrid[i]*xGrid[i]*/ 2.*xGrid[i]-4.  << endl;
	}

	gsl_multiroot_fdfsolver_free(solver1);
	gsl_vector_free(x);

return 0;
}	

///////////////////////////////////////////////////////////////////////
void initializeGrid(double& Length, double& discretization, string& gridSwitch)
{
	if(gridSwitch=="uniform")
	{
	for (int xGridIndex = 0; xGridIndex < numberGridPoints; ++xGridIndex)
		{
			xGrid[xGridIndex] = xGridIndex*discretization; 
		} 
	}	
	
	if (gridSwitch=="quadratic")
	{
		for (int xGridIndex = 0; xGridIndex < numberGridPoints; ++xGridIndex)
		{
			double Length(numberGridPoints*discretization);
			xGrid[xGridIndex] = Length*pow( (xGridIndex/(numberGridPoints*1.) ),2.) ;
		}	
	}
	
	
	std::cout << "gridType: " << gridSwitch << std::endl;
	for (int xGridIndex = 0; xGridIndex < numberGridPoints; ++xGridIndex)
	{
		std::cout << xGrid[xGridIndex] << " is x at gridIndex= " << xGridIndex << std::endl;
	}
}
////////////////////////////////////////////////////////////////////////
void setNumericalParameters(double& Length, double& initialDiscretization, double& error_tol, string& gridSwitch)
{
	initialDiscretization = 0.1;
	gridSwitch = "quadratic";
	//gridSwitch = "uniform";
	error_tol = 1e-7;
	Length = numberGridPoints*initialDiscretization;
}
/////////////////////////////////////////////////////////////////////////
int set_equationSystem_nonlinODE(const gsl_vector* x, void* params,gsl_vector* equationVector)
{
	double a = ((struct parameters*) params)-> lambda; // <=> a = (params*).c1, where params* points to instance of type struct parameters* : pointer of type params* points to instance of type parameters that has element c1 and c2
	double equation[numberGridPoints];	
	double dydx(0.),y(0.),y_0;
	double x_i(0.);
	double yData[numberGridPoints];
	gsl_spline* current_spline = gsl_spline_alloc(splineT,numberGridPoints);
	gsl_interp_accel* current_accel = gsl_interp_accel_alloc();
	
	updateSpline(x,current_spline, current_accel);

	y_0 = gsl_spline_eval(current_spline,0.,current_accel);
	equation[0] = y_0+4.; // for 2x-4=y(x)
	//equation[0] = 1.-y_0;	// for 1-x**2 = y(x) nonvanishing 2nd derivative at ends precludes interpolation
	for (int i = 1; i< numberGridPoints;i++)
	{
		x_i = xGrid[i];	
		y = gsl_spline_eval(current_spline,x_i,current_accel);
		dydx = gsl_spline_eval_deriv(current_spline,x_i,current_accel);
		
		//equation[i] = dydx*(x_i+2.)*(2.*x_i+4.)-y*y;
		equation[i] = dydx*dydx+y-2.*x_i;
		//equation[i] = 0.25*dydx*dydx+y-1.;
	}

	for(int i = 0; i< numberGridPoints; i++)
	{
		gsl_vector_set(equationVector,i,equation[i]);
	}

	gsl_interp_accel_free(current_accel);
	gsl_spline_free(current_spline);

	return GSL_SUCCESS;
}
////////////////////////////////////////////////////////////////
void updateSpline(const gsl_vector* x, gsl_spline* localSplineG1, gsl_interp_accel* localAccelG1)
{
	
	double yDataG1[numberGridPoints];
	
/////////////////////////////////////////// G2 ////////////////////////////////////////////////
	for(int i =0; i< numberGridPoints;i++)
	{
		yDataG1[i] = gsl_vector_get(x,i);
	}
	
	gsl_spline_init(localSplineG1,xGrid,yDataG1,numberGridPoints);


}
///////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
int set_jacobian_equationSystem_nonlinODE(const gsl_vector* x, void* params, gsl_matrix* jacobian)
{
	double d_x(1e-8);
	gsl_vector* equationVectorAt_x = gsl_vector_alloc(numberGridPoints);
	gsl_vector* equationVectorAt_xdx = gsl_vector_alloc(numberGridPoints);
	gsl_vector* xVector = gsl_vector_alloc(numberGridPoints);
	gsl_vector* xdxVector = gsl_vector_alloc(numberGridPoints);
 	gsl_vector_memcpy(xVector,x);
	gsl_vector_memcpy(xdxVector,x);
	double jacobian_ij(1e5);
	
	set_equationSystem_nonlinODE(xVector, params, equationVectorAt_x);

	for (int j=0;j<numberGridPoints;j++)
	{
		gsl_vector_memcpy(xdxVector,xVector);
		gsl_vector_set(xdxVector,j,gsl_vector_get(xVector,j)+d_x);
		set_equationSystem_nonlinODE(xdxVector, params, equationVectorAt_xdx);
		for (int i=0;i<numberGridPoints;i++)
		{
			
			jacobian_ij = ( gsl_vector_get(equationVectorAt_xdx,i) - gsl_vector_get(equationVectorAt_x,i) )/d_x;
			gsl_matrix_set(jacobian, i, j, jacobian_ij);
	///////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////
		}
	}

	gsl_vector_free(equationVectorAt_x);
	gsl_vector_free(equationVectorAt_xdx);
	gsl_vector_free(xVector);
	gsl_vector_free(xdxVector);


	return GSL_SUCCESS;
}
/////////////////////////////////////////////////////////////////////////
int set_equationSystem_nonlinODE_fdf(const gsl_vector* x, void* params, gsl_vector* equationVector, gsl_matrix* jacobian)
{
	set_equationSystem_nonlinODE(x, params, equationVector);
////////////////////////////////////////////////////////////////////////////////////////////////
	set_jacobian_equationSystem_nonlinODE(x, params, jacobian);
	
	return GSL_SUCCESS;
}
//////////////////////////////////////////////////////////////////////////////
void initializeSolutionVector(double* initialGuess,gsl_vector* x)
{
	for (int i = 0; i<numberGridPoints; i++)
	{
		initialGuess[i] = 2.*xGrid[i];
		gsl_vector_set(x,i,initialGuess[i]);
	}	
}
void printState (gsl_multiroot_fdfsolver* solver)
{
	cout << "iterations= " << iterations << " x_0= " << gsl_vector_get(solver->x, 0) << " sum_i |f_i(x)|= " << ( fabs(gsl_vector_get(solver->f, 0))+fabs(gsl_vector_get(solver->f, 1)) ) << endl;    

}
