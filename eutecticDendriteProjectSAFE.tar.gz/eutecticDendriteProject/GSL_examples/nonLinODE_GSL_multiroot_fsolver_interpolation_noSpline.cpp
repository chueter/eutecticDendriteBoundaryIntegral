#include <iostream>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_multiroots.h>
#include <gsl/gsl_interp.h>
#include <gsl/gsl_spline.h>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include  <math.h>

#define numberGridPoints  250

using namespace std;

struct parameters{
double lambda;
};

size_t iterations(0);
//const gsl_interp_type* splineT = gsl_interp_linear;
//gsl_spline* spline = gsl_spline_alloc(splineT,numberGridPoints);
double xGrid[numberGridPoints];
//gsl_interp_accel* accel1 = gsl_interp_accel_alloc();
vector <double>discretization(numberGridPoints,0.);

//void update_spline(const gsl_vector* x);
void setNumericalParameters(double& Length,double& initialDiscretization, double& error_tol, string& gridSwitch);
void initializeGrid(double& Length, double& initialDiscretization, string& gridSwitch);
void printState (gsl_multiroot_fsolver* solver);
void initializeSolutionVector(double* initialGuess, gsl_vector* x);
int equationSystem_nonlinODE(const gsl_vector* x, void* params, gsl_vector* equationVector);

int main()
{
	double initialDiscretization(0.),error_tol(1.),Length(0.);
	string gridSwitch;
	int status(0);
	double initialGuess[numberGridPoints];
	struct parameters nonlinODE_Parameters = {1.0};
	gsl_vector* x = gsl_vector_calloc(numberGridPoints);

	setNumericalParameters(Length,initialDiscretization,error_tol,gridSwitch);
	initializeGrid(Length,initialDiscretization,gridSwitch);
	initializeSolutionVector(initialGuess,x);
 	//gsl_spline_init(spline,xGrid,initialGuess,numberGridPoints);

	const gsl_multiroot_fsolver_type* fsolverT = gsl_multiroot_fsolver_hybrids;
	gsl_multiroot_fsolver* solver1= gsl_multiroot_fsolver_alloc(fsolverT,numberGridPoints) ;
	gsl_multiroot_function model_nonlinODE = {&equationSystem_nonlinODE, numberGridPoints, &nonlinODE_Parameters};
	gsl_multiroot_fsolver_set(solver1,&model_nonlinODE,x);
 	printState(solver1);
 	
	do
	{
		iterations++;
		status = gsl_multiroot_fsolver_iterate(solver1);
		printState(solver1);

		if (status) {break;}

		status = gsl_multiroot_test_residual(solver1->f, error_tol);
	}
	while (status == GSL_CONTINUE && iterations < 1000);
	
	cout << "status= " << gsl_strerror(status) << endl;

	for (int i=0;i<numberGridPoints;i++)
	{
		cout << i << " x= " << xGrid[i] << " root[i]= " << gsl_vector_get(solver1->x, i) << " = " << xGrid[i]*exp(-xGrid[i]) << endl;
	}

	gsl_multiroot_fsolver_free(solver1);
	gsl_vector_free(x);
	//gsl_interp_accel_free(accel1);

return 0;
}	

///////////////////////////////////////////////////////////////////////
void initializeGrid(double& Length, double& initialDiscretization, string& gridSwitch)
{
	if(gridSwitch=="uniform")
	{
	for (int xGridIndex = 0; xGridIndex < numberGridPoints; ++xGridIndex)
		{
			xGrid[xGridIndex] = xGridIndex*initialDiscretization; 
		} 
	}	
	
	if (gridSwitch=="quadratic")
	{
		for (int xGridIndex = 0; xGridIndex < numberGridPoints; ++xGridIndex)
		{
			double Length(numberGridPoints*initialDiscretization);
			xGrid[xGridIndex] = Length*pow( (xGridIndex/(numberGridPoints*1.) ),2.) ;
		}	
	}
	
	
	for (int i = 1; i<numberGridPoints; i++)
	{
		discretization.at(i) = xGrid[i]-xGrid[i-1];
	}
	discretization.at(0) = discretization.at(1); 
	
	std::cout << "gridType: " << gridSwitch << std::endl;
	for (int xGridIndex = 0; xGridIndex < numberGridPoints; ++xGridIndex)
	{
		std::cout << xGrid[xGridIndex] << " is x at gridIndex= " << xGridIndex << std::endl;
	}
}
////////////////////////////////////////////////////////////////////////
void setNumericalParameters(double& Length, double& initialDiscretization, double& error_tol, string& gridSwitch)
{
	initialDiscretization = 0.08;
	//gridSwitch = "quadratic";
	gridSwitch = "uniform";
	error_tol = 1e-7;
	Length = numberGridPoints*initialDiscretization;
}
/////////////////////////////////////////////////////////////////////////
int equationSystem_nonlinODE(const gsl_vector* x, void* params,gsl_vector* equationVector)
{
	double a = ((struct parameters*) params)-> lambda; // <=> a = (params*).c1, where params* points to instance of type struct parameters* : pointer of type params* points to instance of type parameters that has element c1 and c2
	double equation[numberGridPoints];	
	double dydx(0.),y_i(0.),y_im1(0.);
	double x_i(0.);

	//update_spline(x);

	equation[0] = gsl_vector_get(x,0);
	for (int i = 1; i< numberGridPoints;i++)
	{
		x_i = xGrid[i];	
		//y = gsl_spline_eval(spline,x_i,accel1);
		y_i = gsl_vector_get(x,i);
		y_im1 = gsl_vector_get(x,i-1);
		//dydx = gsl_spline_eval_deriv(spline,x_i,accel1);
		dydx = (1./discretization.at(i))*(y_i-y_im1);
		equation[i] = pow((dydx-exp(-a*xGrid[i])),2.0)-pow(y_i,2.0);
		//equation[i] = pow(dydx,2.0)-1.;
	
		//cout << " x_i= " << x_i << " y= " << y << " dydx= " << dydx << " eq[i]= " << equation[i] << endl;

	}
	//if (iterations > 1) {exit(1);}

	for(int i = 0; i< numberGridPoints; i++)
	{
		gsl_vector_set(equationVector,i,equation[i]);
	}

	return GSL_SUCCESS;
}
/////////////////////////////////////////////////////////////////////////
void initializeSolutionVector(double* initialGuess,gsl_vector* x)
{
	for (int i = 0; i<numberGridPoints; i++)
	{
		initialGuess[i] = 2.0;
		gsl_vector_set(x,i,initialGuess[i]);
	}	
}
/////////////////////////////////////////////////////////////////////
void printState (gsl_multiroot_fsolver* solver)
{
	cout << "iterations= " << iterations << " x_0= (" << gsl_vector_get(solver->x, 0) << ") sum_i |f_i(x)|= " << ( fabs(gsl_vector_get(solver->f, 0))+fabs(gsl_vector_get(solver->f, 1)) ) << endl;    

}
/////////////////////////////////////////////////////////////////
// void update_spline(const gsl_vector* x)
// {
// 	double rootEstimate[numberGridPoints];
// 	for (int i=0;i<numberGridPoints;i++)
// 	{
// 		rootEstimate[i] = gsl_vector_get(x,i);
// 	}
// 	gsl_spline_init(spline,xGrid,rootEstimate,numberGridPoints);
// }
//////////////////////////////////////////////////////////////////////








