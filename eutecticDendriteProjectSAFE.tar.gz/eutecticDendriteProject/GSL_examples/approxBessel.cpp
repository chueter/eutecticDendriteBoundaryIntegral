 /////////////////////////////////////////////////////////    
    
     if(etham<=2.) 
       {
         BesKm=s18acc(etham,NAGERR_DEFAULT);
	 f1=exp(-x2)*BesKm;
       }
     else
     {
        f1=(exp(-x2-etham)/sqrt(etham))*nr_besselk0(etham);
     }
     
     if(ethap<=2.) 
       {
         BesKp=s18acc(ethap,NAGERR_DEFAULT);
	 f2=exp(-x2)*BesKp;
       }
     else
     {
        f2=(exp(-x2-ethap)/sqrt(ethap))*nr_besselk0(ethap);
     }  
     f=f1+f2;
     
     
     
 /////////////////////////////////////////////////////////////
