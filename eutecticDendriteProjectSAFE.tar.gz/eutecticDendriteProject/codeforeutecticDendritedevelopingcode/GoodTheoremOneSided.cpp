#include <iostream>
#include <fstream>
#include <sstream>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_multiroots.h>
#include <gsl/gsl_interp.h>
#include <gsl/gsl_spline.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_integration.h>
#include <gsl/gsl_sf.h>
#include <list>
#include <vector>
#include <cmath>

#define numberGridPoints  60 
#define numberGridPointsInt 20
#define numberGridPointsExt 40 // must be numberGridPoints= (numberGridPointsInt+numberGridPointsExt)
#define addGridPoints 5
//numberGridPoints is #of points when doing ONE grid from -inf to +inf. since we have on both 

using namespace std;


struct parameters{
double peclet1;
double peclet2;
double delta1;
double delta2;
double slope1;	// in entire code, suffix 1 means that the quantity is considered on the right branch.
double slope2;
};

struct integralParameters{
double sigma;
double xObserv;
double yObserv;
gsl_spline* splineIntloc;
gsl_interp_accel* accelIntloc;
gsl_spline* splineExtloc;
gsl_interp_accel* accelExtloc;
gsl_spline* kappa_splineInt;
gsl_spline* kappa_splineExt;
gsl_interp_accel* kappa_accelInt;
gsl_interp_accel* kappa_accelExt;
};
////////////////////////////////// testing variables
//bool shifted(0);
bool testedIntegrandAtxObs(0);
/////////////////////////////////// variables of standard types  ///////////////////////////
const  double PI=4.*atan(1.0);
double DcInt_DcExt(100.); // ratio of miscibility gaps
double alpha(1e5),gammaD(1e5),pExt(1e5),pG2(1e5),deltaInt(1e5),deltaExt(1e5),deltaG2(1e+5),slopeInt(1e5),slopeExt(1e5),initialDisc(1e5),A_end(1e5),B_end(1e5),C_end(1e5),tailFactor(1e5),angle_two_phi(100.),d_over_r(100.),a_over_r(100.);
int BC_switch(10000);

//////////////////////////////////// gsl specific variables, arrays, lists, vectors, other STL type instances   
size_t iterations(0);
int errorCount(0);
const gsl_interp_type* splineT = gsl_interp_cspline;
double xGridExt[numberGridPointsExt+2*addGridPoints],xGridInt[numberGridPointsInt+2*addGridPoints];
double prolonguedYGridInt[numberGridPointsInt+2*addGridPoints],prolonguedYGridExt[numberGridPointsExt+2*addGridPoints];
vector <double> Discretization(numberGridPoints+2*addGridPoints,10.);
vector <double> A_N_R((numberGridPoints+1)/2+addGridPoints,10.);
vector <double> B_N_R((numberGridPoints+1)/2+addGridPoints,10.);
vector <double> C_N_R((numberGridPoints+1)/2+addGridPoints,10.);
vector <double> locCurvature(numberGridPoints+1,10.);
vector <double> curvature(numberGridPoints+1,10.);
vector <double> HMK_curvature_Ext((numberGridPoints+1)/2,10.);
vector <double> HMK_curvature_Int((numberGridPoints+1)/2,10.);
vector <double> integrand(numberGridPoints+1,10.);
////////////////////////////////////////// functions which do not return value ////////////////////////////
void setNumericalParameters(double& Length,double& initialDiscretization, double& error_tol, string& gridSwitch, double& p1_o_p2/*, const gsl_vector* x*/);
void initializeGridAndSolution(double& discretization, string& gridSwitch,string& loadValue, gsl_vector* x, double& p1_o_p2);
void printState (gsl_multiroot_fdfsolver* solver/*gsl_multiroot_fsolver* solver*/);
void printChangingParams(gsl_vector* x_solution);
void defineGrid(double& discretization, string& gridSwitch);
void loadSolution();
void initializeSolutionVector(gsl_vector* x);
void setFileNames(string& namePath,  string& YofXFileName, string& shapeCheckFileName, string& fileName_gnuThermal, int goodConvergeSwitch,string& fileName_IntegralsCheck,string& gridSwitch);
void displayInitialGuess(gsl_vector* x);
void testIvantsovRelationWithLocalSplines(gsl_vector* x);
void defineFittingParabola(const gsl_vector* x);
void displayFittingParabolaAndDisc();
void updateSplines(gsl_vector* x, gsl_spline* localSplineInt, gsl_spline* localSplineExt, gsl_interp_accel* localAccelInt, gsl_interp_accel* localAccelExt, gsl_spline* kappa_splineInt, gsl_spline* kappa_splineExt, gsl_interp_accel* kappa_accelInt, gsl_interp_accel* kappa_accelExt);
void calc_curv_HMK(vector<double>& s,vector<double>& x,vector<double>&
y, vector<double>& nx, vector<double>& ny, vector<double>& curv);
void calc_sep(vector<double>& s,vector<double>& x,vector<double>&
y,vector<double>& xm,vector<double>& ym,vector<double>& sp);
float sgn(float val);
void checkIntegrands(gsl_vector* x);

////////////////////////////////////////// functions which do return value ////////////////////////////
int set_equationSystem_Meiron(const gsl_vector* x, void* params, gsl_vector* equationVector);
int set_equationSystem_Meiron_fdf(const gsl_vector* x, void* params, gsl_vector* equationVector, gsl_matrix* jacobian);
int set_jacobian_equationSystem_Meiron(const gsl_vector* x, void* params, gsl_matrix* jacobian);
double exactDiffusionIntegrand_conservationLaw(double x, void* params);
double exactDiffusionIntegrand_locEq(double x, void* params);

string IntToString ( int number);
string DoubleToString ( double doubleNumber);

int main(int argc, char** argv)
{
	if ((argv[1]) == NULL)
	{	
		cout << " -------------------------------------------------------- " << endl;
		cout << " fix if load or noload of old result: " << endl;
		cout << " [program name] load " << endl;
		cout << " [program name] noload " << endl; 
		cout << " -------------------------------------------------------- " << endl;
		exit(1);
	}
	string loadSwitch(argv[1]);
	cout << " -------------------------------------------------------- " << endl;
	cout << " call: " << argv[0] << " " << argv[1] << endl;
	cout << " -------------------------------------------------------- " << endl;
///////////////////////////////////////////////////////////////////////////////////////////////
	double discretization(0.),error_tol(0.0001),systemLength(0.),p1_o_p2(0.);
	string gridSwitch;
	int status(0)/*,goodConvergeSwitch(0)*/;
		
	
	gsl_vector* x = gsl_vector_calloc(numberGridPoints+1);
	setNumericalParameters(systemLength,discretization,error_tol,gridSwitch,p1_o_p2/*,x*/);
	
	struct parameters meiron_Parameters = {pExt,pG2,deltaExt,deltaG2,slopeInt,slopeExt};
	
	initializeGridAndSolution(discretization,gridSwitch,loadSwitch,x,p1_o_p2);
	cout << " test end " << endl;
	// commented for testing grid
	//defineFittingParabola(x);
	//displayFittingParabolaAndDisc();
	
	checkIntegrands(x);
	
	exit(1);
////////////////////////////////////// UP TO HERE EVERYTHING FINE. //////////////////////////////
//// also tested in setEq -delta-function*1/2 of integrand if proper -Delta/2 comes out for p=0.01,0.1,1.0 - works 

	//exit(1);
////////////////////////////////// asymm Meiron ///////////////////////////////////////////////////////////////
  	const gsl_multiroot_fdfsolver_type* fdfsolverT = gsl_multiroot_fdfsolver_gnewton;/*hybridsj*/
  	gsl_multiroot_fdfsolver* solver1= gsl_multiroot_fdfsolver_alloc(fdfsolverT,numberGridPoints+1) ;

 	gsl_multiroot_function_fdf model_Meiron = 						{&set_equationSystem_Meiron,&set_jacobian_equationSystem_Meiron,&set_equationSystem_Meiron_fdf, numberGridPoints+1, &meiron_Parameters};

	gsl_multiroot_fdfsolver_set(solver1,&model_Meiron,x);
	
	printState(solver1);

//////////////////////////////////////////////////////////////////////////////////////////////////
	do
	{
		iterations++;
		status = gsl_multiroot_fdfsolver_iterate(solver1);
	
		printState(solver1);

		printChangingParams((solver1->x));
		
// 		for (int i=0; i<numberGridPoints+1;i++)
// 		{
// 			cout << " -Delta/2(" << i << ")= " << integrand.at(i) << endl;
// 		}

		if (status) {break;}

		status = gsl_multiroot_test_residual(solver1->f, error_tol);
	}
	while (status == GSL_CONTINUE && iterations < 1000);
	
	cout << "status= " << gsl_strerror(status) << endl;

	// commented out for testing grid, wrong grid names 
// 	for (int i=0; i<numberGridPoints+1;i++)
// 	{
// 		cout << "x,root(x),y_Iv: " <<  ( (i<(numberGridPoints+1)/2) ? (xGridExt[addGridPoints+i]) :(xGridInt[addGridPoints+i-(numberGridPoints+1)/2]) ) << " " << gsl_vector_get(solver1->x,i) << " " << ( (i<(numberGridPoints+1)/2) ? -0.5*pow((xGridExt[addGridPoints+i]),2.) :-0.5*pow((xGridInt[addGridPoints+i-(numberGridPoints+1)/2]),2.0)  )  << endl;
// 		
// 	}  

	
 	gsl_multiroot_fdfsolver_free(solver1);
	gsl_vector_free(x);

	cout << " hier samma !" << endl;
////////////////////////////////////////////////////////////////////////////////////////////////////

return 0;
}	

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
void checkIntegrands(gsl_vector* x)
{
    double xObs(0.),yObs(1e5);
    double Integral(100.),error(1e5),intIntegral_locEq(10.),extIntegral_locEq(10.),intIntegral_conservationLaw(10.),extIntegral_conservationLaw(10.),conservationLawIntegral(10.),locEqIntegral(10.),sigma(1e5);

	gsl_set_error_handler_off();
	
	gsl_spline* current_splineInt = gsl_spline_alloc(splineT,numberGridPointsInt+2*addGridPoints);
	gsl_spline* current_splineExt = gsl_spline_alloc(splineT,numberGridPointsExt+2*addGridPoints);
	gsl_interp_accel* current_accelInt = gsl_interp_accel_alloc();
	gsl_interp_accel* current_accelExt = gsl_interp_accel_alloc();
  
	gsl_spline* kappa_splineInt = gsl_spline_alloc(splineT,numberGridPointsInt);
	gsl_spline* kappa_splineExt = gsl_spline_alloc(splineT,numberGridPointsExt);
	gsl_interp_accel* kappa_accelInt = gsl_interp_accel_alloc();
	gsl_interp_accel* kappa_accelExt = gsl_interp_accel_alloc();
  
	
	updateSplines(x, current_splineInt, current_splineExt, current_accelInt, current_accelExt,kappa_splineInt, kappa_splineExt, kappa_accelInt, kappa_accelExt);
	
	gsl_integration_workspace* w = gsl_integration_workspace_alloc(2000);
	//gsl_function integrateExactDiffKernel;
	
	struct integralParameters currentParams = {sigma,xObs,yObs,current_splineInt,current_accelInt,current_splineExt,current_accelExt,kappa_splineInt, kappa_splineExt, kappa_accelInt, kappa_accelExt};
	
	for (int i = 0; i< numberGridPointsExt+numberGridPointsInt;i++)
	{
		//testedShiftAtxObs = false;
		size_t n_evaluations;
		if (i < numberGridPointsInt)
		{
		    xObs = xGridInt[i+addGridPoints];	
		    yObs = gsl_spline_eval(current_splineInt,xObs,current_accelInt);
		}
		else if (i >= numberGridPointsInt)
		{
		    xObs = xGridExt[i+addGridPoints-numberGridPointsInt];	
		    yObs = gsl_spline_eval(current_splineExt,xObs,current_accelExt);
		}
		else {cout << " fuckinn shit Man " << endl;}
// 		dydx = gsl_spline_eval_deriv(current_splineExt,xObs,current_accelExt);
// 		d2ydx2 = gsl_spline_eval_deriv2(current_splineExt,xObs,current_accelExt);
		//kappa = -d2ydx2/pow((1+dydx*dydx),1.5);
		//kappa = gsl_spline_eval(kappa_splineExt,xObs,kappa_accelExt);
		
/////////////////////////////////////////// arbitrary p integral ////////////////////////////////////////////////
		gsl_function integrateExactDiffKernel;
		
// 		integrateExactDiffKernel.function = &exactDiffusionIntegrand_conservationLaw;
// 		integrateExactDiffKernel.params =  &currentParams;
// 		currentParams.yObserv = yObs;
// 		currentParams.xObserv = xObs;
// 
// 		gsl_integration_qng(&integrateExactDiffKernel, 0., xGridExt[addGridPoints]/*tailFactor*xGridExt[addGridPoints+numberGridPointsExt-1]*/,0,1e-7,&Integral,&error,&n_evaluations);
// 		conservationLawIntegral = Integral;
//  		gsl_integration_qng(&integrateExactDiffKernel, xGridExt[addGridPoints], tailFactor*xGridExt[addGridPoints+numberGridPointsExt-1],0,1e-7,&Integral,&error,&n_evaluations);
//  /////////////////////////////////////////////////////////////////////////////////
// 		conservationLawIntegral += Integral;
//////////////////////////////////////arbitrary p integral ////////////////////////////////////////////////////////////////
		integrateExactDiffKernel.function = &exactDiffusionIntegrand_locEq;
		integrateExactDiffKernel.params =  &currentParams;
		currentParams.yObserv = yObs;
		currentParams.xObserv = xObs;

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// 		cout << " integr. limit check: " << xGrid[addGridPoints+(numberGridPoints-1)/2-1] << " " << xGrid[addGridPoints+(numberGridPoints-1)/2+1] << endl;
// 		exit(1);

		gsl_integration_qng(&integrateExactDiffKernel, 0.,1./*tailFactor*xGridExt[addGridPoints+numberGridPointsExt-1]*/, 0,1e-7,&Integral,&error,&n_evaluations);
		intIntegral_locEq = Integral;
		gsl_integration_qng(&integrateExactDiffKernel, 1.,tailFactor*xGridExt[addGridPoints+numberGridPointsExt-1], 0,1e-7,&Integral,&error,&n_evaluations);
		intIntegral_locEq += Integral;
// 
////////////////////////////////////////////////////////////////

//		Integral = conservationLawIntegral + locEqIntegral;
		double yTheo(0.);
		
		if (i < numberGridPointsInt-1)
		{
			yTheo=(/*-*/slopeInt*(xObs-xGridInt[addGridPoints+numberGridPointsInt-1]));
		}
		else if ((i == numberGridPointsInt-1)||(i == numberGridPointsInt))
		{
			yTheo=0.;
		}
		else if ((i == numberGridPointsInt+1))
		{
			yTheo=slopeExt*((xObs)-xGridExt[addGridPoints]);
		}
		else if ((i > numberGridPointsInt+1))
		{
			yTheo=slopeExt*(xGridExt[addGridPoints+1]-xGridExt[addGridPoints])-0.5*pow(xObs-xGridExt[addGridPoints+1],2.0) ;
		}
		
		cout << "x,ySpline,yTheory,Integral= " << xObs << " , " << yObs << " , " <<  yTheo-yObs <<  " , " <<intIntegral_locEq << endl;
// 		cout << "xObs,kappaSpline,kappaTheory= " << xObs << " , " <<  ((i < numberGridPointsInt) ? (gsl_spline_eval(kappa_splineInt,xObs,kappa_accelInt)) : (gsl_spline_eval(kappa_splineExt,xObs,kappa_accelExt))) << " , " << 1./pow((1.+ xObs*xObs),1.5) << endl;
		//cout << "xObs = " << xObs << "integral = " << Integral << endl;
	}
	cout << " parabola shit:A,B,C= " << A_end << " " << B_end << " " << C_end << endl; 
	
	
	gsl_integration_workspace_free(w);

	gsl_interp_accel_free(current_accelInt);
	gsl_interp_accel_free(current_accelExt);
	gsl_spline_free(current_splineInt);
	gsl_spline_free(current_splineExt);

	gsl_interp_accel_free(kappa_accelInt);
	gsl_interp_accel_free(kappa_accelExt);
	gsl_spline_free(kappa_splineInt);
	gsl_spline_free(kappa_splineExt);
	
	
	
exit(1);

}
///////////////////////////////////////////////////////////////////////
void initializeGridAndSolution(double& discretization, string& gridSwitch, string& loadValue, gsl_vector* x, double& p1_o_p2)
{
	if (loadValue == "load")
	{
		loadSolution();
	}
	else if (loadValue == "noload")
	{
		defineGrid(discretization, gridSwitch);
		initializeSolutionVector(x); 
	}
	else 
	{
		cout << " -------------------------------------------------------- " << endl;
		cout << " please fix if you want to: " << endl;
		cout << " -------------------------------------------------------- " << endl;
		cout << " load old solutions: enter [program name] load " << endl;
		cout << " start from asymptotical Ivantsov solution: enter [program name] noload " << endl;
		cout << " -------------------------------------------------------- " << endl;
		cout << " now please call program again with described flag values" << endl;
		exit(1);
	}
}
/////////////////////////////////////////////////////////////////////////////////
void loadSolution()
{
	
}
//////////////////////////////////////////////////////////////////////////////////
void defineGrid(double& discretization, string& gridSwitch)
{
	const int NumberOfPointsInt(numberGridPointsInt);
	const int NumberOfPointsExt(numberGridPointsExt);
	vector<double> intGrid,extGrid,swapGrid;
	double xValue(1e5);
	// Discretization is vector <double> with n+2*add elmnts
/////////////////////////////////////////////////////////////////////////////////////////////////////////	
	if (gridSwitch=="tanh")
	{
		double x1(1e5),x2(1e5),h1(1e5),h2(1e5);
		
		intGrid.push_back(-0.5);
		intGrid.push_back(-0.4);
		intGrid.push_back(-0.3);
		intGrid.push_back(-0.2);
		intGrid.push_back(-0.1); // addgridPoints additional points on x<0
		intGrid.push_back(0.);
/////////////////////////////////////////////////// for tanh-density int grid BEGIN		
// 		for (int xGridIndex=1; xGridIndex < NumberOfPointsInt; ++xGridIndex)
// 		{
// 			h1 = 5./(NumberOfPointsInt);
// 			h2 = (((NumberOfPointsInt))*discretization)/(((NumberOfPointsInt))*(10.*tanh(0.)+11.));
// 			x1 = xGridIndex*h1;
// 			x2 = 10.*tanh(x1-5.)+11.;
// 			xValue = 2.*xGridIndex*h2*x2;
// 			xValue = 0.0075 + pow(xValue,1.);
// 			intGrid.push_back(xValue);
// 		}
// 		
// 		for (int xGridIndex=addGridPoints; xGridIndex < NumberOfPointsInt+addGridPoints; ++xGridIndex)
// 		{
// 			intGrid.at(xGridIndex) = 1.-intGrid.at(xGridIndex)/intGrid.at(NumberOfPointsInt-1+addGridPoints);
// 		}
// 		
// 		for ( int i=0; i<NumberOfPointsInt;i++)
// 		{
// 			
// 			{
// 				swapGrid.push_back(intGrid.at(NumberOfPointsInt+addGridPoints-i-1));
// 			}
// 			 
// 		}
// 		
// 		for (int i = addGridPoints; i < NumberOfPointsInt+addGridPoints; i++)
// 		{
// 		  intGrid.at(i) = swapGrid.at(i-addGridPoints);
// 		}		
/////////////////////////////////////////////////// for tanh-density int grid END
/////////////////////////////////////////////////// for uniform int grid BEGIN

		for (int i = addGridPoints+1; i < NumberOfPointsInt+addGridPoints; i++)
		{
		  intGrid.push_back( (i-addGridPoints)*1./((NumberOfPointsInt-1)*1.) ); 
		}	
/////////////////////////////////////////////////// for uniform int grid END

 		extGrid.push_back(1.0);
		for (int xGridIndex=1; xGridIndex < NumberOfPointsExt+addGridPoints; ++xGridIndex)
		{
			h1 = 5./(NumberOfPointsExt);
			h2 = (((NumberOfPointsExt))*discretization)/(((NumberOfPointsExt))*(10.*tanh(0.)+11.));
			x1 = xGridIndex*h1;
			x2 = 10.*tanh(x1-5.)+11.;
			xValue = 2.*xGridIndex*h2*x2;
			xValue = 0.015 + pow(xValue,1.5);
			extGrid.push_back(1.00+xValue);
		}
		
		//exit(1);
		
		 for (int i=0;i<numberGridPointsInt+addGridPoints;i++)
		 {
		      xGridInt[i] = intGrid.at(i);
		 }
		
		
		  for (int i=0;i<numberGridPointsExt+addGridPoints;i++)
		 {
		      xGridExt[addGridPoints+i] = extGrid.at(i); 
		 }
		
		
		for (int i=0;i<addGridPoints;i++)
		{
		    xGridInt[addGridPoints+numberGridPointsInt+i] = 1.1+i*0.1; // see below
		    xGridExt[i] = 0.5+i*0.1; // just puts addGPts points left to extGrid: 0.5,0.6,...0.9
		}
	
	
	}
	
// 	for (int i = 0;i<numberGridPointsInt+2*addGridPoints;i++)
// 	{
// 	    cout << "i,xGridInt " << i << " " << xGridInt[i] << endl;
// 	}
// 	for (int i = 0;i<numberGridPointsExt+2*addGridPoints;i++)
// 	{
// 	    cout << "i,xGridExt " << i << " " << xGridExt[i] << endl;
// 	} 
	
/////////////////////////////////////   Discretization   //////////////////////////////////////////////////////////////////////
	for (int gridIndex = 1; gridIndex < (numberGridPointsInt+addGridPoints); gridIndex++)
	{
		Discretization.at(gridIndex) = xGridInt[gridIndex]-xGridInt[gridIndex-1];
	}
	Discretization.at(0) = Discretization.at(1);
	
	for (int gridIndex = 1; gridIndex < numberGridPointsExt+addGridPoints; gridIndex++)
	{
		Discretization.at(numberGridPointsInt+addGridPoints+gridIndex) = xGridExt[gridIndex+addGridPoints]-xGridExt[gridIndex+addGridPoints-1];
		 // cout << " i= " << gridIndex << " i2= " << numberGridPointsInt+addGridPoints+gridIndex << " disc.at(i)= " << Discretization.at(numberGridPointsInt+addGridPoints+gridIndex) << endl;  
	}
	Discretization.at(numberGridPointsInt+addGridPoints) = Discretization.at(numberGridPointsInt+addGridPoints-1);  
// for (int gridIndex = 0; gridIndex < numberGridPoints+2*addGridPoints; gridIndex++);
// 	cout << " test x2 " << endl;

	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
}
////////////////////////////////////////////////////////////////////////
void setNumericalParameters(double& Length, double& initialDiscretization, double& error_tol, string& gridSwitch, double& p1_o_p2)
{

	initialDiscretization = 0.2;
	gridSwitch = "tanh";
	error_tol = 5.*1e-3;
	Length = numberGridPoints*initialDiscretization;
	initialDisc = initialDiscretization; // initialDisc is used as globally declared parameter for normalShift and naming 
	pExt = 0.2;
	pG2 = 0.2;
	deltaExt = 1.; //sqrt(PI*pExt)*exp(pExt)*erfc(sqrt(pExt));
	deltaInt = 1.;
	DcInt_DcExt= 1.;
	deltaG2 = sqrt(PI*pG2)*exp(pG2)*erfc(sqrt(pG2));
	p1_o_p2 = pExt/pG2;
	a_over_r=1.;

	//angle_two_phi = 4.;
	angle_two_phi = 4.7123;  //angle = 270 degrees
	//angle_two_phi = 2.0944;	//angle = 120 degrees
	//angle_two_phi = 1.3963; //angle = 80 degrees
	//angle_two_phi = 1.2217; //angle = 70 degrees
	//angle_two_phi = 1.0472; //angle = 60 degrees	
	//angle_two_phi = 1.792; //slopeInt = -0.8 
	//angle_two_phi = 2.7468; //slopeInt = -0.2
	
	slopeInt = -1./tan(/*angle_delta*/-0.5*angle_two_phi);
	slopeExt = -1./tan(/*angle_delta*/+0.5*angle_two_phi);

	//exit(1); 
	
	//slopeInt = -0.0; // right branch
	//slopeExt =  0.0; // left branch

	cout << " slopeInt: " << slopeInt  << " slopeExt: " << slopeExt << endl;

	tailFactor = 1.;

}
/////////////////////////////////////////////////////////////////////////
// int set_equationSystem_Meiron(const gsl_vector* x, void* params,gsl_vector* equationVector)
// {
// 	static size_t nr_access(0);
// 	//cout << " # accesses to setEqSystem " << nr_access << endl;
// 	++nr_access;
// 	
// // for meiron problem, since slopes are not changed, not necessary yet to set prolongued splines for calculated slope in each step.
// 	double equation[numberGridPoints];	
// 	for (int i=0;i<numberGridPoints;i++) {equation[i] = 100.;}
// 	double dydx(0.),yObs(0.),y_0,y_m1,y_p1,kappa(0.),/*kappaHMK(0.),*/d2ydx2(0.),sigma(1e5)/*,delta(1e5)*/;
// 	//double LocalShift_x, LocalShift_y;
// 	double xObs(0.);
// 	double Integral(100.),error(1e5)/*,xComponent_of_n(10.)*/, /*yComponent_of_n(10.),*//*leftIntegral(10.),rightIntegral(10.),*/leftIntegral_locEq(10.),rightIntegral_locEq(10.),leftIntegral_conservationLaw(10.),rightIntegral_conservationLaw(10.),conservationLawIntegral(10.),locEqIntegral(10.);
// 
// 	gsl_set_error_handler_off();
// 	
// 	gsl_spline* kappaRHP_splineG1 = gsl_spline_alloc(splineT,numberGridPointsInt);
// 	gsl_spline* kappaLHP_splineG2 = gsl_spline_alloc(splineT,numberGridPointsExt);
// 	gsl_interp_accel* kappaRHP_accelG1 = gsl_interp_accel_alloc();
// 	gsl_interp_accel* kappaLHP_accelG2 = gsl_interp_accel_alloc();
// 
// 	gsl_spline* current_splineG1 = gsl_spline_alloc(splineT,numberGridPointsInt+2*addGridPoints);
// 	gsl_spline* current_splineG2 = gsl_spline_alloc(splineT,numberGridPointsExt+2*addGridPoints);
// 	gsl_interp_accel* current_accelG1 = gsl_interp_accel_alloc();
// 	gsl_interp_accel* current_accelG2 = gsl_interp_accel_alloc();
// 
// // 	d_over_r = gsl_vector_get(numberGridPointsInt-1); // first element where x=1
// 	a_over_r = gsl_vector_get(x,numberGridPointsInt); // second element where x=1 
// 
// 	updateSplines(x, current_splineG1, current_splineG2, current_accelG1, current_accelG2,kappaRHP_splineG1, kappaLHP_splineG2, kappaRHP_accelG1, kappaLHP_accelG2);
// 	
// 	gsl_integration_workspace* w = gsl_integration_workspace_alloc(2000);
// 	//gsl_function integrateExactDiffKernel;
// 	
// 	struct integralParameters currentParams = {sigma,xObs,yObs,current_splineG1,current_accelG1,current_splineG2,current_accelG2,kappaRHP_splineG1, kappaLHP_splineG2, kappaRHP_accelG1, kappaLHP_accelG2};
// 	
// 	
// 	//////////////////////////////////////////////////////////////////////////////////////////////
// 	y_0 =  gsl_spline_eval(current_splineG2,0.,current_accelG2);
// 	y_m1 = gsl_spline_eval(current_splineG2,xGridG2[addGridPoints+(numberGridPoints+1)/2-2],current_accelG2);
// 	y_p1 = gsl_spline_eval(current_splineG1,xGridG1[addGridPoints+1],current_accelG1);
// 
// // ////////////////////////////////////////////////// equationVectorSetting ////////////////////////	
// 	for (int i = 0; i< numberGridPointsInt-1;i++)
// 	{
// 		//testedShiftAtxObs = false;
// 		size_t n_evaluations;
// 		xObs = xGridG2[i+addGridPoints];	
// 		yObs = gsl_spline_eval(current_splineG2,xObs,current_accelG2);
// 		dydx = gsl_spline_eval_deriv(current_splineG2,xObs,current_accelG2);
// 		d2ydx2 = gsl_spline_eval_deriv2(current_splineG2,xObs,current_accelG2);
// 		//kappa = -d2ydx2/pow((1+dydx*dydx),1.5);
// 		kappa = gsl_spline_eval(kappaLHP_splineG2,xObs,kappaLHP_accelG2);
// 		//kappaHMK = gsl_spline_eval(kappaLHP_splineG2,xObs,kappaLHP_accelG2);
// 		//HMK_curvature_LHP.at(i) = kappaHMK;
// 		//curvature.at(i) = kappa;
// /////////////////////////////////////////// arbitrary p integral ////////////////////////////////////////////////
// 		gsl_function integrateExactDiffKernel;
// 		integrateExactDiffKernel.function = &exactDiffusionIntegrand_conservationLaw;
// 		integrateExactDiffKernel.params =  &currentParams;
// 		currentParams.yObserv = yObs;
// 		currentParams.xObserv = xObs;
// 
// //////////////////////////////////////////kappa from parabola at outer points ////////////////////////////
// 
// ///////// add here specific kappa !!!
// // 		if (i==0)
// // 		{
// // 			//kappa = -d2ydx2/pow((1.+(dydx)*(dydx)),1.5);
// // 			kappa = -2.*C_N_L_end/pow((1.+(B_N_L_end-xObs*C_N_L_end)*(B_N_L_end-xObs*C_N_L_end)),1.5);
// // 		}
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 		gsl_integration_qng(&integrateExactDiffKernel, tailFactor*xGridG2[addGridPoints], /*xGridG2[addGridPoints+(numberGridPoints+1)/2-2]*/-0.00,0,1e-7,&Integral,&error,&n_evaluations);
// 		leftIntegral_conservationLaw = Integral;
// 
//  		gsl_integration_qng(&integrateExactDiffKernel,/*xGridG1[addGridPoints+1]*/0.00, tailFactor*xGridG1[addGridPoints+numberGridPointsInt-1],0,1e-7,&Integral,&error,&n_evaluations);
// 		rightIntegral_conservationLaw = Integral;
// 		conservationLawIntegral = leftIntegral_conservationLaw + rightIntegral_conservationLaw;
// //////////////////////////////////////////////////////////////////////////////////
// 
// //////////////////////////////////////arbitrary p integral ////////////////////////////////////////////////////////////////
// 		integrateExactDiffKernel.function = &exactDiffusionIntegrand_locEq;
// 		integrateExactDiffKernel.params =  &currentParams;
// 		currentParams.yObserv = yObs;
// 		currentParams.xObserv = xObs;
// 
// /////////////////////////////////////////////////////////////////////////////////////////////////////////
// // 		cout << " integr. limit check: " << xGrid[addGridPoints+(numberGridPoints-1)/2-1] << " " << xGrid[addGridPoints+(numberGridPoints-1)/2+1] << endl;
// // 		exit(1);
// 
// 		gsl_integration_qng(&integrateExactDiffKernel, tailFactor*xGridG2[addGridPoints], -0.00/*xGridG2[addGridPoints+(numberGridPoints+1)/2-2]*/,0,1e-7,&Integral,&error,&n_evaluations);
// 		leftIntegral_locEq = Integral;
// 
// 		gsl_integration_qng(&integrateExactDiffKernel,0.00/*xGridG1[addGridPoints+1]*/, tailFactor*xGridG1[addGridPoints+numberGridPointsInt-1],0,1e-7,&Integral,&error,&n_evaluations);
// 		rightIntegral_locEq = Integral;
// 
// 		locEqIntegral = leftIntegral_locEq + rightIntegral_locEq;
// ////////////////////////////////////////////////////////////////
// 
// 		Integral = conservationLawIntegral + locEqIntegral;
// 
// 		equation[i] = 0.5*(deltaG2-kappa*sigma)-(pG1/(2.*PI))*Integral; // exact integral
// 		
// 		integrand.at(i) = pG1*(1./(2.*PI))*Integral; // integrand is checked for -Delta/2 - behaviour.
// 		curvature.at(i) = kappa;
// 
// //cout << " @xObs,yObs= " << xObs << " " << yObs << " Delta= " << deltaG2 << " Delta/2 calc. =" << (pG1/(2.*PI))*Integral << endl;
// 
// //cout << " in setEq: xObs,yObs= " << xObs << " " << yObs << " kappa= " << kappa << " integrand= " << integrand.at(i) << endl;
// //cout << "  equation[i]= " << equation[i] << " i= " << i << endl; 		
// 
// if(!(fabs(equation[i]) < 10000.))
// {
// 	cout << " eq. error @ i=" << i/*+(numberGridPoints+1)/2*/ << endl;
// 	cout << " @xObs,yObs= " << xObs << " " << yObs << " Delta= " << deltaG2 << " Delta/2 calc. =" << (pG1/(2.*PI))*Integral << endl;
// 	cout << " (pG1/(2.*PI))*Integral= " << (pG1/(2.*PI))*Integral << " kappa= " << kappa << " deltaG2= " << deltaG2 << " sigma= " << sigma << endl;
// 	exit(1);
// }
// 
// 
// 	}
//  //exit(1);
// // 
// // 	
//  	equation[numberGridPointsInt-1] = y_m1-slopeInt*xGridG2[addGridPoints+numberGridPointsInt-2];
//  	equation[numberGridPointsInt] = y_p1-slopeExt*xGridG1[addGridPoints+1];
// 
// //cout << " equation[" << (numberGridPoints+1)/2-1 << "]= "  <<  equation[(numberGridPoints+1)/2-1] << endl;
// //cout << " equation[" << (numberGridPoints+1)/2<< "]= " << equation[(numberGridPoints+1)/2] << endl;
// // 
// 	for (int i = 1; i< numberGridPointsExt;i++)
// 	{
// 		size_t n_evaluations;
// 		xObs = xGridG1[i+addGridPoints];	
// 
// 		yObs = gsl_spline_eval(current_splineG1,xObs,current_accelG1);
// 		
// 		dydx = gsl_spline_eval_deriv(current_splineG1,xObs,current_accelG1);
// 		d2ydx2 = gsl_spline_eval_deriv2(current_splineG1,xObs,current_accelG1);
// 		//kappa = -d2ydx2/pow((1+dydx*dydx),1.5);
// 		kappa = gsl_spline_eval(kappaRHP_splineG1,xObs,kappaRHP_accelG1);
// 		//kappaHMK = gsl_spline_eval(kappaRHP_splineG1,xObs,kappaRHP_accelG1);
// 		//HMK_curvature_RHP.at(i+2) = kappaHMK;
// 		//curvature.at(i+(numberGridPoints-1)/2+2) = kappa;
// /////////////////////////////// arbitray p integral /////////////////////////////
// 		gsl_function integrateExactDiffKernel;
// 		integrateExactDiffKernel.function = &exactDiffusionIntegrand_conservationLaw;
// 		integrateExactDiffKernel.params =  &currentParams;
// 		currentParams.xObserv = xObs;
// 		currentParams.yObserv = yObs;
// 
// ///////////////////////////take kappa not from saito spline for outer points /////////////
// ////// rescaled kappa!
// // 		if (i==(numberGridPoints+1)/2-1)
// // 		{
// // 			//kappa = -d2ydx2/pow((1.+(dydx)*(dydx)),1.5);
// // 			kappa = -2.*C_end/pow((1.+(B_end-xObs*C_end)*(B_end-xObs*C_end)),1.5);
// // 		}
// //////////////////////////////////////////////////////////////////////////////////////////
// 		gsl_integration_qng(&integrateExactDiffKernel, tailFactor*xGridG2[addGridPoints], /*xGridG2[addGridPoints+(numberGridPoints+1)/2-2]*/-0.00,0,1e-7,&Integral,&error,&n_evaluations);
// 		leftIntegral_conservationLaw = Integral;
// 
//  		gsl_integration_qng(&integrateExactDiffKernel,0.00/*xGridG1[addGridPoints+1]*/, tailFactor*xGridG1[addGridPoints+numberGridPointsInt-1],0,1e-7,&Integral,&error,&n_evaluations);
// 		rightIntegral_conservationLaw = Integral;
// 		conservationLawIntegral = leftIntegral_conservationLaw + rightIntegral_conservationLaw;
// 
// 
// ////////////////////////////////////arbitrary p integral /////////////////////////////////////////////////////////////////////
// 		integrateExactDiffKernel.function = &exactDiffusionIntegrand_locEq;
// 		integrateExactDiffKernel.params =  &currentParams;
// 		currentParams.xObserv = xObs;
// 		currentParams.yObserv = yObs;
// 
// //////////////////////////////////////////////////////////////////////////////////////////
// 		gsl_integration_qng(&integrateExactDiffKernel, tailFactor*xGridG2[addGridPoints], /*xGridG2[addGridPoints+(numberGridPoints+1)/2-2]*/-0.00,0,1e-7,&Integral,&error,&n_evaluations);
// 		leftIntegral_locEq = Integral;
// 
// 		gsl_integration_qng(&integrateExactDiffKernel,/*xGridG1[addGridPoints+1]*/0.00, tailFactor*xGridG1[addGridPoints+numberGridPointsInt-1],0,1e-7,&Integral,&error,&n_evaluations);
// 
// 		rightIntegral_locEq = Integral;
// 
// 		locEqIntegral = leftIntegral_locEq+rightIntegral_locEq;
// 
// 		Integral = conservationLawIntegral + locEqIntegral;
// 
// 
// 		integrand.at(i+numberGridPointsExt) = pG1*(1./(2.*PI))*Integral;
// 		curvature.at(i+numberGridPointsExt) = kappa;
// 		
// 		equation[i+numberGridPointsExt] = 0.5*(deltaG1-kappa*sigma)-(pG1/(2.*PI))*Integral;
// 
// 
// //cout << " @xObs,yObs= " << xObs << " " << yObs << " Delta= " << deltaG1 <<  " Delta/2 calc. =" << (pG1/(2.*PI))*Integral << endl;
// //cout << " equation[" << i+(numberGridPoints+1)/2 << "]= " << equation[i+(numberGridPoints+1)/2] << endl;
// // if(/* !(fabs(equation[i]) < 10000.) */  i==1)
// // {
// // 	cout << " eq. error @ i=" << i+(numberGridPoints+1)/2 << endl;
// // 	//exit(1);
// // }
// 	}
// //exit(1);
// 	equation[0] = (0.); // zero slope
// 	equation[numberGridPoints] = B_end;
// // 	equation[0] = (pG1/pG2)*C_N_L_end+0.5; 
// // 	equation[numberGridPoints-1] = C_end+0.5;
// 
//  
// // 
// // 
// // 
// 	for(int i = 0; i< numberGridPoints; i++)
// 	{
// 		gsl_vector_set(equationVector,i,equation[i]);
// 	}
// 	gsl_integration_workspace_free(w);
// 
// 	gsl_interp_accel_free(current_accelG1);
// 	gsl_interp_accel_free(current_accelG2);
// 	gsl_spline_free(current_splineG1);
// 	gsl_spline_free(current_splineG2);
// 
// 	gsl_interp_accel_free(kappaRHP_accelG1);
// 	gsl_interp_accel_free(kappaLHP_accelG2);
// 	gsl_spline_free(kappaRHP_splineG1);
// 	gsl_spline_free(kappaLHP_splineG2);
// 
// 
// 	return GSL_SUCCESS;
// 
// }
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////
// int set_jacobian_equationSystem_Meiron(const gsl_vector* x, void* params, gsl_matrix* jacobian)
// {
// 	double d_x(1e-8);
// 	gsl_vector* equationVectorAt_x = gsl_vector_alloc(numberGridPoints);
// 	gsl_vector* equationVectorAt_xdx = gsl_vector_alloc(numberGridPoints);
// 	gsl_vector* xVector = gsl_vector_alloc(numberGridPoints);
// 	gsl_vector* xdxVector = gsl_vector_alloc(numberGridPoints);
//  	gsl_vector_memcpy(xVector,x);
// 	gsl_vector_memcpy(xdxVector,x);
// 	double jacobian_ij(1e5);
// 	
// 	set_equationSystem_Meiron(xVector, params, equationVectorAt_x);
// 
// 	for (int j=0;j<numberGridPoints;j++)
// 	{
// 		gsl_vector_memcpy(xdxVector,xVector);
// 		gsl_vector_set(xdxVector,j,gsl_vector_get(xVector,j)+d_x);
// 		set_equationSystem_Meiron(xdxVector, params, equationVectorAt_xdx);
// 		for (int i=0;i<numberGridPoints;i++)
// 		{
// 			
// 			jacobian_ij = ( gsl_vector_get(equationVectorAt_xdx,i) - gsl_vector_get(equationVectorAt_x,i) )/d_x;
// 			gsl_matrix_set(jacobian, i, j, jacobian_ij);
// 		}
// 	}
// 
// 	gsl_vector_free(equationVectorAt_x);
// 	gsl_vector_free(equationVectorAt_xdx);
// 	gsl_vector_free(xVector);
// 	gsl_vector_free(xdxVector);
// 
// 
// 	return GSL_SUCCESS;
// }
// /////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////
// int set_equationSystem_Meiron_fdf(const gsl_vector* x, void* params, gsl_vector* equationVector, gsl_matrix* jacobian)
// {
// 	set_equationSystem_Meiron(x, params, equationVector);
// ////////////////////////////////////////////////////////////////////////////////////////////////
// 	set_jacobian_equationSystem_Meiron(x, params, jacobian);
// 	
// 	return GSL_SUCCESS;
// }
// /////////////////////////////////////////////////////////////////////////
// //////////////////////////////////////////////////////////////////////////////
void initializeSolutionVector(gsl_vector* x)
{
	double initialGuess[numberGridPoints], d_over_aInitialGuess(1.),a_over_rInitialGuess(1.);
	vector<double> solutionIntExt,shortGrid;
////////////////////////////////////////////////////////////////////////////////////////////////////////	
	for (int xGridIndex = addGridPoints; xGridIndex < numberGridPoints+addGridPoints; xGridIndex++)
	{
		//shortGrid.push_back(xGrid[xGridIndex]);	
		if (xGridIndex<(numberGridPointsInt+addGridPoints)) 
		{
			shortGrid.push_back(xGridInt[xGridIndex]);
		}
		else if (xGridIndex>=numberGridPointsInt+addGridPoints)
		{
			shortGrid.push_back(xGridExt[xGridIndex-(numberGridPointsInt)]);
		}
	}	 
	
// for (vector<double>::iterator iter = shortGrid.begin(); iter != shortGrid.end(); ++iter)
// {
// 	cout << " in initializeSolutionVector 1: shortGrid= " << *iter << endl;	
// }
//exit(1);



	for (int i=0;i<numberGridPoints;i++)
	{
		if (i < numberGridPointsInt-1)
		{
 			solutionIntExt.push_back(/*-*/slopeInt*(shortGrid.at(i)-xGridInt[addGridPoints+numberGridPointsInt-1]));
			//solutionIntExt.push_back(slopeExt*(shortGrid.at(numberGridPointsInt+1)-xGridExt[addGridPoints]));
		}
		else if ((i == numberGridPointsInt-1)||(i == numberGridPointsInt))
		{
			//solutionIntExt.push_back(slopeExt*(shortGrid.at(numberGridPointsInt+1)-xGridExt[addGridPoints]));
			solutionIntExt.push_back(0.);
		}
		else if ((i == numberGridPointsInt+1))
		{
			solutionIntExt.push_back(slopeExt*(shortGrid.at(i)-xGridExt[addGridPoints]));
		}
		else if ((i > numberGridPointsInt+1))
		{
			solutionIntExt.push_back(slopeExt*(shortGrid.at(numberGridPointsInt+1)-xGridExt[addGridPoints])-0.5*pow(shortGrid.at(i)-xGridExt[addGridPoints+1],2.0) );
		}
		
		
		
		
// 		if (i < numberGridPointsInt-1)
// 		{
// 			solutionIntExt.push_back(0.5-0.5*pow(shortGrid.at(i),2.0));
// 		}
// 		else if ((i == numberGridPointsInt-1)||(i == numberGridPointsInt))
// 		{
// 			solutionIntExt.push_back(0.5-0.5*pow(shortGrid.at(i),2.0));
// 		}
// 		else if ((i == numberGridPointsInt+1))
// 		{
// 			solutionIntExt.push_back(0.5-0.5*pow(shortGrid.at(i),2.0));
// 		}
// 		else if ((i > numberGridPointsInt+1))
// 		{
// 			solutionIntExt.push_back(0.5-0.5*pow(shortGrid.at(i),2.0) );
// 		}
		
		
		else 
		{
			cout << " error in initializing with Ivantsov solution " << endl;
			exit(1);
		}
	}

// for (vector<double>::iterator iter = solutionIntExt.begin(); iter != solutionIntExt.end(); ++iter)
// {
// 	cout << " in initializeSolutionVector 1: solutionIntExt= " << *iter << endl;	
// }

	
	for (vector<double>::iterator iter = solutionIntExt.begin(); iter != solutionIntExt.end(); ++iter )
	{
		static int i(0);
		if (i < (numberGridPoints))
		{
			initialGuess[i] = *iter; 
		}
		++i;
		initialGuess[numberGridPointsInt-1] = d_over_aInitialGuess;
		initialGuess[numberGridPointsInt] = a_over_rInitialGuess;
	}	 

// for (int i=0; i<numberGridPoints+1;i++)
// {
// 	cout << " in initializeSolutionVector 1: initialGuess[" << i << "]" << initialGuess[i] << endl;
// }
// exit(1);
	
	for (int i = 0; i<numberGridPoints; i++)
	{
		gsl_vector_set(x,i,initialGuess[i]);
	}	
 
// for (int i=0; i<numberGridPoints;i++)
// {
// 	cout << " in initializeSolutionVector 1: x[" << i << "]" << gsl_vector_get(x,i) << endl;
// }
// exit(1);


}
// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
// void printState (gsl_multiroot_fdfsolver* solver)
// {
// 	double sum_error(0.);
// 	for (int i=0; i<numberGridPoints+1;i++)	
// 	{
// 		cout << " f(i): " << gsl_vector_get(solver->f, i) <<  " @i= " << i << endl;
// 		if (i<(numberGridPoints+1)/2) 
// 		{
// 			cout << " x= " << xGridG2[addGridPoints+i] << endl; 
// 		}
// 		else if (i>=(numberGridPoints+1)/2) 
// 		{
// 			cout << " x= " << xGridG1[addGridPoints+i-(numberGridPoints+1)/2] << endl; 
// 		}
// 
// 		sum_error += fabs(gsl_vector_get(solver->f, i));
// 	}
// 	cout << "iterations= " << iterations << " x_tip(sigma)= " << gsl_vector_get(solver->x, (numberGridPoints+1)/2-1) << " x_tip(delta)= " << gsl_vector_get(solver->x, (numberGridPoints+1)/2) << " sum_i |f_i(x)|= " << sum_error << endl;    
// 
// 
// }
// //////////////////////////////////////////////////////////////////////////////////////////////////////////
// void setFileNames(string& pathName, string& YofXFileName,  string& shapeCheckFileName, string& fileName_gnuShape, int goodConvergeSwitch,string& fileName_IntegralsCheck,string& gridSwitch)
// {
// 	
// 	string al = DoubleToString(alpha);
// 	string Gd = DoubleToString(gammaD);
// 	string PG1 = DoubleToString(pG1);
// 	string PG2 = DoubleToString(pG2);
// 	string n = IntToString(numberGridPoints);
// 	string tipS1 = DoubleToString(slopeInt); // Gamma 1 is right interface: x >0 , y<0
// 	string tipS2 = DoubleToString(slopeExt); // Gamma 2 is left interface: x<0,y<0
// 	string Ver = "asymm_arbitraryAngles_";
// 	string BC = IntToString(BC_switch);
// 	string Disc = DoubleToString(initialDisc);
// 	string YofX = "YofX_";
// 	string goodConverge = IntToString(goodConvergeSwitch); // goodConvergeSwitch = 1 means good Convergence
// //////////////////////////////////////////////////////////
// /////////// change path  /////////////////////
// 	pathName = "solidSolidAsymmResults/";
// 
// 	string configuration = Ver+"_n_"+n+"_disc_"+Disc+"_grid_"+gridSwitch+"_pG1_"+PG1+"_pG2_"+PG2+"_slopeInt_"+tipS1+"_slopeExt_"+tipS2+"_Gd_"+Gd+"_BC_"+BC+"_goodConverge_"+goodConverge+".dat";
// 
// /////////////////////////////////////////////////////////////////////////////////////////////////
// 	YofXFileName = YofX+configuration;
// 	shapeCheckFileName = "shapeCheck_"+Ver+"_n_"+n+"_disc_"+Disc+"_Gd_"+Gd+".dat";
// 	fileName_IntegralsCheck = "integralsCheck_"+Ver+"_n_"+n+"_disc_"+Disc+"_Gd_"+Gd+".dat";
// 	fileName_gnuShape = "checkShape.gnu";
// }
// ////////////////////////////////////////////////////////////////////////
// ////////////////////////////////////////////////////////////////////////////
// string IntToString ( int number )
// {
//   std::ostringstream oss;
//   
//   oss<< number;
//  
//   return oss.str();
// }
// //////////////////////////////////////////////////////////
// string DoubleToString ( double doubleNumber )
// {
//   std::ostringstream oss;
//  
//   oss<< doubleNumber;
//   
//   return oss.str();
// }
// ////////////////////////////////////////////////////////////
// void displayInitialGuess(gsl_vector* x)
// {
// 	cout << " display initial grids and guess " << endl;
// 
// 	for (int i=0; i< (numberGridPoints+1)/2+2*addGridPoints;i++)
// 	{
// 		cout << "(xGridG2,xGridG1): " << xGridG2[i] << " " << xGridG1[i] << endl;
// 	}
// 	for (int i=0; i< numberGridPoints+1;i++)
// 	{
// 		cout << "(x,root_ini): " << ( (i<(numberGridPoints+1)/2) ? (xGridG2[addGridPoints+i]) :(xGridG1[addGridPoints+i-(numberGridPoints+1)/2]) ) << " "<< gsl_vector_get(x,i) << endl;
// 	}
// }
// //////////////////////////////////////////////////////////
void updateSplines(gsl_vector* x, gsl_spline* localSplineInt, gsl_spline* localSplineExt, gsl_interp_accel* localAccelInt, gsl_interp_accel* localAccelExt, gsl_spline* kappa_splineInt, gsl_spline* kappa_splineExt, gsl_interp_accel* kappa_accelInt, gsl_interp_accel* kappa_accelExt)
{
static int nrAccess(0);
++nrAccess;

	double interpolatedDataInt[numberGridPointsInt+2*addGridPoints],interpolatedDataExt[numberGridPointsExt+2*addGridPoints],interpolatedKappaInt[numberGridPointsInt],interpolatedKappaExt[numberGridPointsExt];
	
	defineFittingParabola(x);


	for(int i =0; i< numberGridPointsInt+2*addGridPoints;i++)
	{	
		interpolatedDataInt[i] = prolonguedYGridInt[i];
		
	}
	for(int i =0; i< numberGridPointsExt+2*addGridPoints;i++)
	{	
		interpolatedDataExt[i] = prolonguedYGridExt[i];
		
	}

	gsl_spline_init(localSplineInt,xGridInt,interpolatedDataInt,numberGridPointsInt+2*addGridPoints);
	gsl_spline_init(localSplineExt,xGridExt,interpolatedDataExt,numberGridPointsExt+2*addGridPoints);

 
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	vector <double> s_vecInt(numberGridPointsInt,0.);
	vector <double> x_vecInt(numberGridPointsInt,0.);
	vector <double> y_vecInt(numberGridPointsInt,0.);
	vector <double> nx_vecInt(numberGridPointsInt,0.);
	vector <double> ny_vecInt(numberGridPointsInt,0.);
	vector <double> curv_vecInt(numberGridPointsInt,0.); 
	
	vector <double> s_vecExt(numberGridPointsExt,0.);
	vector <double> x_vecExt(numberGridPointsExt,0.);
	vector <double> y_vecExt(numberGridPointsExt,0.);
	vector <double> nx_vecExt(numberGridPointsExt,0.);
	vector <double> ny_vecExt(numberGridPointsExt,0.);
	vector <double> curv_vecExt(numberGridPointsExt,0.);
	

	for(int i =0; i<numberGridPointsInt ;i++)
	{	
		x_vecInt.at(i) = xGridInt[addGridPoints+i];
		y_vecInt.at(i) = prolonguedYGridInt[addGridPoints+i];
	}
	for(int i =0; i<numberGridPointsExt ;i++)
	{	
		x_vecExt.at(i) = xGridExt[addGridPoints+i];
		y_vecExt.at(i) = prolonguedYGridExt[addGridPoints+i];
	}

	calc_curv_HMK(s_vecInt, x_vecInt, y_vecInt, nx_vecInt, ny_vecInt, curv_vecInt);
 	calc_curv_HMK(s_vecExt, x_vecExt, y_vecExt, nx_vecExt, ny_vecExt, curv_vecExt);
 	


	size_t xGridIndex(0);
	for (vector<double>::iterator iterInt = curv_vecInt.begin(); iterInt != curv_vecInt.end();  ++iterInt) 
	{
 		interpolatedKappaInt[xGridIndex] = *iterInt;
		++xGridIndex;
	}
	xGridIndex = 0;
	for (vector<double>::iterator iterExt = curv_vecExt.begin(); iterExt != curv_vecExt.end(); ++iterExt) 
	{
 		interpolatedKappaExt[xGridIndex] = *iterExt;
		++xGridIndex;
	}
	
	interpolatedKappaInt[0] = interpolatedKappaInt[1]; // symmetry axis
	interpolatedKappaInt[numberGridPointsInt-1] = interpolatedKappaInt[numberGridPointsInt-2]; //triple junction
	interpolatedKappaExt[0] = interpolatedKappaExt[1]; //triple junction

	double shortXGridInt[numberGridPointsInt];
	for (int i=0; i< numberGridPointsInt;i++)
	{
		shortXGridInt[i] = xGridInt[addGridPoints+i];	
	}
	gsl_spline_init(kappa_splineInt,shortXGridInt,interpolatedKappaInt,numberGridPointsInt);
	
	double shortXGridExt[numberGridPointsExt];
	for (int i=0; i<numberGridPointsExt ;i++)
	{
		shortXGridExt[i] = xGridExt[addGridPoints+i];
	}
	gsl_spline_init(kappa_splineExt,shortXGridExt,interpolatedKappaExt,numberGridPointsExt);

	
	
//////////////////////////////////////////////////////////////////////////////
//	gsl_interp_accel* test_kappaLHP_accelG2 = gsl_interp_accel_alloc();
//for (int i=0; i< (numberGridPoints+1)/2;i++)
//{
//		double xTest = xGridG2[i+addGridPoints];
//		double kappaTest = gsl_spline_eval(kappaLHP_splineG2,xTest,test_kappaLHP_accelG2);
// 		if (kappaTest >= 60.)
// 		{
// 			cout << " in updateSplines: kappa= " << kappaTest << endl; 
// 			cout << " @xTest = " << xTest << endl;
// 			cout << " x[0],x[-1],x[-2] " <<  prolonguedYGridG2[(numberGridPoints-1)/2+addGridPoints-i] << " " << gsl_vector_get(x,(numberGridPoints-1)/2-1) << " " <<  gsl_vector_get(x,(numberGridPoints-1)/2-2) << endl;
// 			cout << " kappa(x[-1]), kappa(x[-2]) " << interpolatedKappaLHP[(numberGridPoints-1)/2-1] << " " << interpolatedKappaLHP[(numberGridPoints-1)/2-2] << endl;
// 			exit(1);
// 		}
//}

// 	cout << " in updateSplines: y(0)= " << gsl_vector_get(x,(numberGridPoints-1)/2) << endl;
// 	exit(1);

}
// ///////////////////////////////////////////////////////////////////////////
double exactDiffusionIntegrand_conservationLaw(double x, void* params)
{
	
	double xObs =((struct integralParameters*) params)-> xObserv;
	
	double KernelSource(10.),Kernel(10.),eta(10.),KernelTilde(10.),etaTilde(10.),norm(10.);
	
	double yObs(1e5);
	double y(1e5),locDisc(10e-7);
	double dydx(0.),d2ydx2(0.);
	double y_x_m_locDisc(15.),y_x_p_locDisc(12.);

	

	
		yObs = ((struct integralParameters*) params)-> yObserv;

		
		if ( (x >= xGridInt[addGridPoints]) && (x <= xGridInt[addGridPoints+numberGridPointsInt-1]))
		{
			y = gsl_spline_eval(( ((struct integralParameters*) params)-> splineIntloc),x,( ((struct integralParameters*) params)-> accelIntloc));

			dydx = -( gsl_spline_eval(( ((struct integralParameters*) params)-> splineIntloc),x-locDisc,( ((struct integralParameters*) params)-> accelIntloc)) - gsl_spline_eval(( ((struct integralParameters*) params)-> splineIntloc),x,( ((struct integralParameters*) params)-> accelIntloc)) )/locDisc;  // straightforward kappa, bad close to 0
			norm=DcInt_DcExt;
			
		}
		else if ( (x >= xGridExt[addGridPoints]) && (x <= xGridExt[addGridPoints+numberGridPointsExt-1]) )
		{
			y = gsl_spline_eval(( ((struct integralParameters*) params)-> splineExtloc),x,( ((struct integralParameters*) params)-> accelExtloc));

			dydx = ( gsl_spline_eval(( ((struct integralParameters*) params)-> splineExtloc),x,( ((struct integralParameters*) params)-> accelExtloc)) - gsl_spline_eval(( ((struct integralParameters*) params)-> splineExtloc),x-locDisc,( ((struct integralParameters*) params)-> accelExtloc)) )/locDisc;
			norm=1.;
		}
		else if ( x > xGridExt[addGridPoints+numberGridPointsExt-1] )
		{
			y = A_end+B_end*x+C_end*x*x;
			y_x_m_locDisc = A_end+B_end*(x-locDisc)+C_end*(x-locDisc)*(x-locDisc);
			y_x_p_locDisc = A_end+B_end*(x+locDisc)+C_end*(x+locDisc)*(x+locDisc);

			dydx = (y-y_x_m_locDisc)/locDisc;

			d2ydx2 = (y_x_p_locDisc-2.*y+y_x_m_locDisc)/(locDisc*locDisc);
			norm=1.;
		}
		else if ( (x < xGridInt[addGridPoints]) || (x > tailFactor*xGridExt[addGridPoints+numberGridPointsExt-1]) )
		{
			cout << " error in integration in testIvantsov relation c " << endl;
			exit(1);
		  
		}
		else 
		{
			cout << " error in integration in testIvantsov relation c " << endl;
			exit(1);
		}
	
	
	eta = sqrt( (x-xObs)*(x-xObs) + (y-yObs)*(y-yObs) );
	if ( a_over_r*pExt*eta >= 0.00000000001 )
	{
		if ((a_over_r*pExt*eta) >= 2.5)
		{
			//KernelSource = sqrt(PI/(2.*pExt*eta))*2.*exp( -pExt*( (yObs-y)+fabs(yObs-y)*(1.+0.5*pow((xObs-x),2.0)/pow((yObs-y),2.0)) )  ); problem: division by 0 if in some iteration step y(x) is symmetric possible. 
			KernelSource = norm*sqrt(PI/(2.*a_over_r*pExt*eta))*2.*exp( -a_over_r*pExt*( (yObs-y)+ eta ));
		}
		else 
		{
			KernelSource = norm*2.*exp(-(a_over_r*pExt*(yObs-y)))*gsl_sf_bessel_K0(a_over_r*pExt*eta);
		}
		Kernel = KernelSource;
	}

	else 
	{
		Kernel = 0.;
	}

	if (!(fabs(Kernel) <= 10000.))
	{
		cout << " source kernel= " << Kernel << endl;
		cout << " exp(-(pExt*(yObs-y)))= " << exp(-(pExt*(yObs-y))) << " gsl_sf_bessel_K0(pExt*eta)= " << gsl_sf_bessel_K0(pExt*eta) << endl;
		cout << " xObs,x,yObs,y= " << xObs << " " << x << " " << yObs << " " << y << endl;
		cout << " sqrt(PI/(2.*pExt*eta))= " << sqrt(PI/(2.*pExt*eta)) << " exp( -pExt*( (yObs-y)+fabs(yObs-y)*(1.+0.5*pow((xObs-x),2.0)/pow((yObs-y),2.0)) )  )= " << exp( -pExt*( (yObs-y)+fabs(yObs-y)*(1.+0.5*pow((xObs-x),2.0)/pow((yObs-y),2.0)) )  ) <<endl;
		cout << " fabs(yObs-y)*(1.+0.5*pow((xObs-x),2.0)/pow((yObs-y),2.0))= "	<< fabs(yObs-y)*(1.+0.5*pow((xObs-x),2.0)/pow((yObs-y),2.0)) << endl;	
		cout << " eta= " << eta << endl; 
		exit(1);
	}

	
	etaTilde =  sqrt( (x+xObs/*-2.*xGridExt[addGridPoints+1]*/)*(x+xObs/*-2.*xGridExt[addGridPoints+1]*/) + (y-yObs)*(y-yObs) );
	if ( a_over_r*pExt*etaTilde >= 0.000000001 )
	{
		if ((a_over_r*pExt*etaTilde) >= 2.5)
		{
			//KernelSource = sqrt(PI/(2.*pExt*eta))*2.*exp( -pExt*( (yObs-y)+fabs(yObs-y)*(1.+0.5*pow((xObs-x),2.0)/pow((yObs-y),2.0)) )  ); problem: division by 0 if in some iteration step y(x) is symmetric possible. 
			KernelSource = norm*sqrt(PI/(2.*a_over_r*pExt*etaTilde))*2.*exp( -a_over_r*pExt*( (yObs-y)+ etaTilde ));
		}
		else 
		{
			KernelSource = norm*2.*exp(-(a_over_r*pExt*(yObs-y)))*gsl_sf_bessel_K0(a_over_r*pExt*etaTilde);
		}
		KernelTilde = KernelSource;
	}

	else 
	{
		KernelTilde = 0.;
	}

	if (!(fabs(KernelTilde) <= 10000.))
	{
		cout << " source kernelTilde= " << KernelTilde << endl;
		cout << " exp(-(pExt*(yObs-y)))= " << exp(-(pExt*(yObs-y))) << " gsl_sf_bessel_K0(pExt*eta)= " << gsl_sf_bessel_K0(pExt*etaTilde) << endl;
		cout << " xObs,x,yObs,y= " << xObs << " " << x << " " << yObs << " " << y << endl;
		cout << " sqrt(PI/(2.*pExt*eta))= " << sqrt(PI/(2.*pExt*etaTilde)) << " exp( -pExt*( (yObs-y)+fabs(yObs-y)*(1.+0.5*pow((xObs-x),2.0)/pow((yObs-y),2.0)) )  )= " << exp( -pExt*( (yObs-y)+fabs(yObs-y)*(1.+0.5*pow((xObs-x),2.0)/pow((yObs-y),2.0)) )  ) <<endl;
		cout << " fabs(yObs-y)*(1.+0.5*pow((xObs-x),2.0)/pow((yObs-y),2.0))= "	<< fabs(yObs-y)*(1.+0.5*pow((xObs-x),2.0)/pow((yObs-y),2.0)) << endl;	
		cout << " eta= " << etaTilde << endl; 
		exit(1);
	}

	return ((Kernel+KernelTilde)*a_over_r*pExt/(2*PI));
}
// ////////////////////////////////////////////////////////////////
// ///////////////////////////////////////////////////////////////////////////
double exactDiffusionIntegrand_locEq(double x, void* params)
{
	
	double sigmaLoc = ((struct integralParameters*) params)-> sigma;
	double xObs =((struct integralParameters*) params)-> xObserv;
	
	double Kernel1sidedPart(10.),Kernel(10.),eta(10.),etaTilde(10.),locEq(10.),kappaLoc(10.),norm(10.);
	
	double yObs(1e5);
	double y(1e5),locDisc(10e-4);
	double dydx(0.),d2ydx2(0.);
	double y_x_m_locDisc(15.),y_x_p_locDisc(12.);

	

		yObs = ((struct integralParameters*) params)-> yObserv;

		if ( (x >= xGridInt[addGridPoints]) && (x <= xGridInt[addGridPoints+numberGridPointsInt-1]))
		{
			y = gsl_spline_eval(( ((struct integralParameters*) params)-> splineIntloc),x,( ((struct integralParameters*) params)-> accelIntloc));

			dydx = ( gsl_spline_eval(( ((struct integralParameters*) params)-> splineIntloc),x,( ((struct integralParameters*) params)-> accelIntloc)) - gsl_spline_eval(( ((struct integralParameters*) params)-> splineIntloc),x-locDisc,( ((struct integralParameters*) params)-> accelIntloc)) )/locDisc;  // straightforward kappa, bad close to 0

			kappaLoc = gsl_spline_eval(( ((struct integralParameters*) params)-> kappa_splineInt),x,( ((struct integralParameters*) params)-> kappa_accelInt));
			norm=DcInt_DcExt;
		}
		else if ( (x >= xGridExt[addGridPoints]) && (x <= xGridExt[addGridPoints+numberGridPointsExt-1]) )
		{
			y = gsl_spline_eval(( ((struct integralParameters*) params)-> splineExtloc),x,( ((struct integralParameters*) params)-> accelExtloc));

			dydx = ( gsl_spline_eval(( ((struct integralParameters*) params)-> splineExtloc),x,( ((struct integralParameters*) params)-> accelExtloc)) - gsl_spline_eval(( ((struct integralParameters*) params)-> splineExtloc),x-locDisc,( ((struct integralParameters*) params)-> accelExtloc)) )/locDisc;
			
			kappaLoc = gsl_spline_eval(( ((struct integralParameters*) params)-> kappa_splineExt),x,( ((struct integralParameters*) params)-> kappa_accelExt));
			norm=1.;
		}
		else if ( x > xGridExt[addGridPoints+numberGridPointsExt-1] )
		{
			y = A_end+B_end*x+C_end*x*x;
			y_x_m_locDisc = A_end+B_end*(x-locDisc)+C_end*(x-locDisc)*(x-locDisc);
			y_x_p_locDisc = A_end+B_end*(x+locDisc)+C_end*(x+locDisc)*(x+locDisc);

			dydx = (y-y_x_m_locDisc)/locDisc;

			d2ydx2 = (y_x_p_locDisc-2.*y+y_x_m_locDisc)/(locDisc*locDisc);

			kappaLoc = - ( d2ydx2/pow((1.+dydx*dydx),1.5) );  // straightforward kappa, bad close to zero
			norm=1.;
		}
		else 
		{
			cout << " error in integration in testIvantsov relation c " << endl;
			exit(1);
		}



 	if (x < xGridExt[addGridPoints]) 
 	{ 
		locEq = (deltaInt/*-kappaLoc*sigmaLoc*/)*norm;
 	}
 	else if (x > xGridExt[addGridPoints])
 	{
 		locEq = (deltaExt/*-kappaLoc*sigmaLoc*/)*norm;
 	}

	eta = sqrt( (x-xObs)*(x-xObs) + (y-yObs)*(y-yObs) );
	if (((a_over_r*pExt*eta) >= 0.00000001) && (fabs(x)>0.000001))
	{
		if ((a_over_r*pExt*eta) >= 4.)
		{
			
			Kernel1sidedPart = locEq*sqrt(PI/(2.*a_over_r*pExt*eta))*exp( -a_over_r*pExt*( (yObs-y)+eta ) )*( ((-dydx*(xObs-x)+(yObs-y))/eta)*(1.+(3./8.)*(1./(a_over_r*pExt*eta))) - 1. );

			
// 			if (!(fabs(Kernel1sidedPart) <= 10000.)) 
// 			{	
// 				cout << " locEq kernel: " << Kernel1sidedPart << endl;   
// 				cout << " x,y,xObs,yObs,eta= " << x << " " << y << " " << xObs << " " << yObs << " " << eta << endl; 
// 				cout << " locEq " << locEq << " sqrt(PI/(2.*pG1*eta)) " << sqrt(PI/(2.*pG1*eta)) << " exp( -pG1*( (yObs-y)+eta ) ) " << exp( -pG1*( (yObs-y)+eta ) ) << endl;
// 				cout << " (-dydx*(xObs-x)+(yObs-y))/eta) " << (-dydx*(xObs-x)+(yObs-y))/eta << " (1.+(3./8.)*(1./(pG1*eta))) " << (1.+(3./8.)*(1./(pG1*eta))) << endl;
// 				cout << " kappaLoc= " << kappaLoc << " sigmaLoc= " << sigmaLoc <<  endl;
// 				exit(1);
// 			}
		}
		else
		{
			Kernel1sidedPart = locEq*exp(-(a_over_r*pExt*(yObs-y)))*( ((-dydx*(xObs-x)+(yObs-y))/eta)*gsl_sf_bessel_K1(a_over_r*pExt*eta) - gsl_sf_bessel_K0(a_over_r*pExt*eta) );


// 			if (!(fabs(Kernel1sidedPart) <= 10000.)) 
// 			{	
// 				cout << " locEq kernel: " << Kernel1sidedPart << endl;   
// 				cout << " x,y,xObs,yObs,eta= " << x << " " << y << " " << xObs << " " << yObs << " " << eta << endl; 
// 				cout << " locEq " << locEq <<  endl;
// 				cout << " (-dydx*(xObs-x)+(yObs-y))/eta) " << (-dydx*(xObs-x)+(yObs-y))/eta << endl;
// 				cout << " kappaLoc= " << kappaLoc << " sigmaLoc= " << sigmaLoc <<  endl;
// 				exit(1);
// 			}
		}
		Kernel = Kernel1sidedPart;
	}

	else 
	{
		Kernel = 0.;
	}

// 	if (!(fabs(Kernel) <= 10000.)) 
// 	{	
// 		cout << " locEq kernel: " << Kernel << endl;   
// 		cout << " x,y,xObs,yObs,eta= " << x << " " << y << " " << xObs << " " << yObs << " " << eta << endl; 
// 		cout << " locEq " << locEq << " sqrt(PI/(2.*pG1*eta)) " << sqrt(PI/(2.*pG1*eta)) << " exp( -pG1*( (yObs-y)+eta ) ) " << exp( -pG1*( (yObs-y)+eta ) ) << endl;
// 		cout << " (-dydx*(xObs-x)+(yObs-y))/eta) " << (-dydx*(xObs-x)+(yObs-y))/eta << " (1.+(3./8.)*(1./(pG1*eta))) " << (1.+(3./8.)*(1./(pG1*eta))) << endl;
// 		cout << " kappaLoc= " << kappaLoc << " sigmaLoc= " << sigmaLoc <<  endl;
// 		exit(1);
// 	}

	etaTilde = sqrt( (x+xObs)*(x+xObs) + (y-yObs)*(y-yObs) );
	if (((a_over_r*pExt*etaTilde) >= 0.00000001) && (fabs(x)>0.000001))
	{
		if ((a_over_r*pExt*etaTilde) >= 4.)
		{
			
			Kernel1sidedPart = locEq*sqrt(PI/(2.*a_over_r*pExt*etaTilde))*exp( -a_over_r*pExt*( (yObs-y)+etaTilde ) )*( ((dydx*(xObs+x)+(yObs-y))/etaTilde)*(1.+(3./8.)*(1./(a_over_r*pExt*etaTilde))) - 1. );

			
// 			if (!(fabs(Kernel1sidedPart) <= 10000.)) 
// 			{	
// 				cout << " locEq kernel: " << Kernel1sidedPart << endl;   
// 				cout << " x,y,xObs,yObs,eta= " << x << " " << y << " " << xObs << " " << yObs << " " << eta << endl; 
// 				cout << " locEq " << locEq << " sqrt(PI/(2.*pG1*eta)) " << sqrt(PI/(2.*pG1*eta)) << " exp( -pG1*( (yObs-y)+eta ) ) " << exp( -pG1*( (yObs-y)+eta ) ) << endl;
// 				cout << " (-dydx*(xObs-x)+(yObs-y))/eta) " << (-dydx*(xObs-x)+(yObs-y))/eta << " (1.+(3./8.)*(1./(pG1*eta))) " << (1.+(3./8.)*(1./(pG1*eta))) << endl;
// 				cout << " kappaLoc= " << kappaLoc << " sigmaLoc= " << sigmaLoc <<  endl;
// 				exit(1);
// 			}
		}
		else
		{
			Kernel1sidedPart = locEq*exp(-(a_over_r*pExt*(yObs-y)))*( ((dydx*(xObs+x)+(yObs-y))/etaTilde)*gsl_sf_bessel_K1(a_over_r*pExt*etaTilde) - gsl_sf_bessel_K0(a_over_r*pExt*etaTilde) );


// 			if (!(fabs(Kernel1sidedPart) <= 10000.)) 
// 			{	
// 				cout << " locEq kernel: " << Kernel1sidedPart << endl;   
// 				cout << " x,y,xObs,yObs,eta= " << x << " " << y << " " << xObs << " " << yObs << " " << eta << endl; 
// 				cout << " locEq " << locEq <<  endl;
// 				cout << " (-dydx*(xObs-x)+(yObs-y))/eta) " << (-dydx*(xObs-x)+(yObs-y))/eta << endl;
// 				cout << " kappaLoc= " << kappaLoc << " sigmaLoc= " << sigmaLoc <<  endl;
// 				exit(1);
// 			}
		}
		Kernel += Kernel1sidedPart;
	}

	else 
	{
		Kernel = 0.;
	}

// 	if (!(fabs(Kernel) <= 10000.)) 
// 	{	
// 		cout << " locEq kernel: " << Kernel << endl;   
// 		cout << " x,y,xObs,yObs,eta= " << x << " " << y << " " << xObs << " " << yObs << " " << eta << endl; 
// 		cout << " locEq " << locEq << " sqrt(PI/(2.*pG1*eta)) " << sqrt(PI/(2.*pG1*eta)) << " exp( -pG1*( (yObs-y)+eta ) ) " << exp( -pG1*( (yObs-y)+eta ) ) << endl;
// 		cout << " (-dydx*(xObs-x)+(yObs-y))/eta) " << (-dydx*(xObs-x)+(yObs-y))/eta << " (1.+(3./8.)*(1./(pG1*eta))) " << (1.+(3./8.)*(1./(pG1*eta))) << endl;
// 		cout << " kappaLoc= " << kappaLoc << " sigmaLoc= " << sigmaLoc <<  endl;
// 		exit(1);
// 	}
 
	return Kernel*a_over_r*pExt/(2*PI);
}

// /////////////////////////////////////////////////////////////////////////////////////////////////////
void defineFittingParabola(const gsl_vector* x)
{
double discl1,discl2,discm1,discm2,discu1,discu2,y_k,y_k_plus,y_k_minus,x_k_minus,x_k,x_k_plus;
////////////////////////////// for right branch x>0 //////////////////////
	discl1 = -Discretization.at(numberGridPoints+addGridPoints-3);
	discl2 = -Discretization.at(numberGridPoints+addGridPoints-3)-Discretization.at(numberGridPoints+addGridPoints-2);
	discm1 = Discretization.at(numberGridPoints+addGridPoints-3);
	discm2 = -Discretization.at(numberGridPoints+addGridPoints-2);
	discu1 = Discretization.at(numberGridPoints+addGridPoints-2)+Discretization.at(numberGridPoints+addGridPoints-3);
	discu2 = Discretization.at(numberGridPoints+addGridPoints-2);
	y_k_minus = gsl_vector_get(x,numberGridPoints-4);
	y_k =gsl_vector_get(x,numberGridPoints-3);
	y_k_plus = gsl_vector_get(x,numberGridPoints-2);
	x_k_minus = xGridExt[numberGridPointsExt+addGridPoints-4];
	x_k = xGridExt[numberGridPointsExt+addGridPoints-3];
	x_k_plus = xGridExt[numberGridPointsExt+addGridPoints-2];

	A_end = y_k_minus*x_k*x_k_plus/(discl1*discl2) + y_k*x_k_minus*x_k_plus/(discm1*discm2) + y_k_plus*x_k_minus*x_k/(discu1*discu2);
	B_end = - y_k_minus*(x_k+x_k_plus) /(discl1*discl2) -  y_k*(x_k_minus+x_k_plus)/(discm1*discm2) -  y_k_plus*(x_k_minus+x_k)/(discu1*discu2);
	C_end =  y_k_minus/(discl1*discl2) + y_k/(discm1*discm2) + y_k_plus/(discu1*discu2);

	///////////////////////////  Prolongation of grids  /////////////////////////

	// First copy 
	for (int sndGridIndex = 0; sndGridIndex < numberGridPointsInt; ++sndGridIndex)
	{
		prolonguedYGridInt[sndGridIndex+addGridPoints] = gsl_vector_get(x,sndGridIndex);
	}
	for (int sndGridIndex = 0; sndGridIndex < numberGridPointsExt; ++sndGridIndex)
	{
		// starting of physical regime of exterior grid is numberGridPointsInt
		prolonguedYGridExt[sndGridIndex+addGridPoints] = gsl_vector_get(x,sndGridIndex+numberGridPointsInt);
	}
	//
	
	for (int sndGridIndex = 0; sndGridIndex < addGridPoints; ++sndGridIndex)
	{
		prolonguedYGridInt[sndGridIndex+addGridPoints+numberGridPointsInt] = slopeInt*(xGridInt[addGridPoints+sndGridIndex+numberGridPointsInt]-xGridInt[addGridPoints+numberGridPointsInt-1]);
		prolonguedYGridInt[sndGridIndex] = prolonguedYGridInt[addGridPoints];
	}
	for (int sndGridIndex = 0; sndGridIndex < addGridPoints; ++sndGridIndex)
	{
		prolonguedYGridExt[sndGridIndex] = slopeExt*(xGridExt[sndGridIndex]-xGridExt[addGridPoints]);
		prolonguedYGridExt[sndGridIndex+addGridPoints+numberGridPointsExt] = A_end+B_end*xGridExt[sndGridIndex+addGridPoints+numberGridPointsExt]+C_end*xGridExt[sndGridIndex+addGridPoints+numberGridPointsExt]*xGridExt[sndGridIndex+addGridPoints+numberGridPointsExt];

	}
	prolonguedYGridInt[addGridPoints+numberGridPointsInt-1] = 0.;
	prolonguedYGridExt[addGridPoints] = 0.;

}
// /////////////////////////////////////////////////////////////////////////////////////////////////////
// void displayFittingParabolaAndDisc()
// {
// 	cout << " show fitting parabolas " << endl;
// 	cout << " parameters: " << endl;
// 	cout << " A_N_L_end,B_N_L_end,C_N_L_end: " << A_N_L_end << " " << B_N_L_end << " " << C_N_L_end << endl;
// 	cout << " A_end,B_end,C_end: " << A_end << " " << B_end << " " << C_end << endl;
// 	for (int i = 0; i< (numberGridPoints+1)/2+2*addGridPoints;i++)
// 	{
// 		cout << "(x,y_prol,p1/p2*y_Iv)G2 " << xGridG2[i]  << "," << prolonguedYGridG2[i] << " " << -(pG1/pG2)*xGridG2[i]*xGridG2[i]*0.5  << endl;
// 	}
// 	cout << " ------------------------------------------------------- " << endl;
// 	for (int i = 0; i< (numberGridPoints+1)/2+2*addGridPoints;i++)
// 	{
// 		cout << "(x,y_prol,y_Iv)G1 " << xGridG1[i]  << "," << prolonguedYGridG1[i] << " " << -xGridG1[i]*xGridG1[i]*0.5 << endl;
// 	}
// 	cout << " ------------------------------------------------------- " << endl;
// 
// }
// ////////////////////////////////////////////////////////////////
// void printChangingParams(gsl_vector* x_solution)
// {
// 	cout << " coefficients of parabolic prolongation " << endl;
// 	cout << " left branch: ANLend,BNLend,CNLend: " << A_N_L_end << " " << B_N_L_end << " " << C_N_L_end << endl;  
// 	cout << " right branch: ANRend,BNRend,CNRend: " << A_end << " " << B_end << " " << C_end << endl;
// 	cout << " coefficients of calculated shape last point of each branch/(-xObs*xObs/2) approx 1? " << endl;
// 	cout << " left side: y(-xMax)/y_Iv(-xMax)" <<  gsl_vector_get(x_solution,0)/(-0.5*(xGridG2[addGridPoints]*xGridG2[addGridPoints])) << endl;
// 	cout << " right side: y(xMax)/y_Iv(xMax)" <<  gsl_vector_get(x_solution,numberGridPoints)/(-0.5*(xGridG1[(numberGridPoints+1)/2+addGridPoints-1]*xGridG1[(numberGridPoints+1)/2+addGridPoints-1])) << endl; 
// 	cout << " xSolution(xMax)= " << gsl_vector_get(x_solution,numberGridPoints) << " xMax= " << xGridG1[(numberGridPoints+1)/2+addGridPoints-1] << endl;
// }
// ////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////////////////////////////
// void setNormalVectorComponents (double & xComponent_of_n, double & yComponent_of_n,struct integralParameters* intParams, double & xp)
// {
// 	double corr_dydx(0.);
// 	if (xp < 0.)
// 	{
// 		corr_dydx = gsl_spline_eval_deriv(intParams-> splineG2loc,xp,intParams-> accelG2loc);
// 	}
// 	else if (xp > 0.)
// 	{
// 		corr_dydx = gsl_spline_eval_deriv(intParams-> splineG1loc,xp,intParams-> accelG1loc);
// 	}
// 	double theta2 = atan(corr_dydx);   
// 	xComponent_of_n = -sin(theta2);
// 	yComponent_of_n = cos(theta2);
// 
// 	if (!(fabs(xComponent_of_n)<10000.))
// 	{
// 		cout << " xp= " << xp << " yObs  " << gsl_spline_eval(intParams-> splineG2loc,xp,intParams-> accelG2loc) << endl;
// 		cout << " in set nX, nY: " << xComponent_of_n << " &nY= " << yComponent_of_n << endl;
// 		cout << " theta2 " << theta2 << endl;
// 		exit(1);
// 	}
// }
// ////////////////////////////////////////////////////////////////////////////
void calc_sep(vector<double>& s,vector<double>& x,vector<double>&
y,vector<double>& xm,vector<double>& ym,vector<double>& sp)
{
	double dx, dy, ds,x1,y1;
	int n=x.size();
	x1=-x[1];
	y1=y[1];
	ds=s[0];
	dx=x[0]-x1;
	dy=y[0]-y1;
	sp[0]=sqrt(dx*dx+dy*dy);
	xm[0]=dx/sp[0];
	ym[0]=dy/sp[0];


  for(int m=1;m<n;++m)
     {
      ds=s[m]-s[m-1];
      dx=x[m]-x[m-1];
      dy=y[m]-y[m-1];
      sp[m]=sqrt(dx*dx+dy*dy);
      xm[m]=dx/sp[m];
      ym[m]=dy/sp[m];
  
     }
}
// ////////////////////////////////////////////////////////////////////////////////////
void calc_curv_HMK(vector<double>& s,vector<double>& x,vector<double>&
y, vector<double>& nx, vector<double>& ny, vector<double>& curv)
{
	
  int n=x.size();
  vector<double> xm(n),ym(n),sp(n);
  
  double bunsen;  
  double bunshi;
  double bbx, bby;
  double bunbo;
	
  calc_sep(s,x,y,xm,ym,sp);
	
  for(int m=0;m<n-1;m++)
     {
      bunsen=xm[m]*xm[m+1]+ym[m]*ym[m+1];
      bunshi=xm[m]*ym[m+1]-ym[m]*xm[m+1];
      bbx=-sp[m]*ym[m+1]-sp[m+1]*ym[m];
      bby=sp[m]*xm[m+1]+ sp[m+1]*xm[m];

      bunbo = sqrt(bbx*bbx + bby*bby);
 
      curv[m]=-2.*bunshi/bunbo;
 
     if ((bunbo==0))
     {
	cout << " RHP/m=" << m << " bbx,bby= " << bbx << "," << bby << endl; 
	cout << " bunsen, bunshi= " << bunsen << " " << bunshi << endl;
	cout << " m=0: sp,ym,xm " << sp[m] << " " << ym[m] << " " << xm[m] << endl;
	cout << " m+1: sp,ym,xm " << sp[m+1] << " " << ym[m+1] << " " << xm[m+1] << endl; 
     	cout << "nan curv. Warning!\n";
 
        exit(1);
     }
     }
 
 
}
// /////////////////////////////////////////////////////////////////////////////
// float sgn(float val)
// {
// double outValue(10.);
//     if (val<0)
//     {
//         outValue = -1.;
//     }
//     else if (val>0)
//     {
//         outValue= 1.;
//     }
//     else if (val==0)
//     {
//         outValue= 1.;
//     }
// 
// 	return outValue;
// } 
// 
// 
// 
// 
// 
// 
// 
